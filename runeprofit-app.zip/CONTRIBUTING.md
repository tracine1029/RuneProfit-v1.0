# Contributing to RuneProfit

Thank you for your interest in contributing to RuneProfit! This document provides guidelines and information for contributors.

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (latest stable version)
- Dart SDK (included with Flutter)
- Android Studio or VS Code with Flutter extensions
- Git

### Development Setup
1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/runeprofit.git`
3. Navigate to the project: `cd runeprofit`
4. Install dependencies: `flutter pub get`
5. Run the app: `flutter run`

## 📝 How to Contribute

### Reporting Bugs
1. Check existing issues to avoid duplicates
2. Use the bug report template
3. Include:
   - Device information
   - App version
   - Steps to reproduce
   - Expected vs actual behavior
   - Screenshots if applicable

### Suggesting Features
1. Check existing feature requests
2. Use the feature request template
3. Explain the use case and benefits
4. Provide mockups or examples if possible

### Code Contributions
1. Create a new branch: `git checkout -b feature/your-feature-name`
2. Make your changes following our coding standards
3. Test thoroughly
4. Commit with clear messages
5. Push to your fork
6. Create a pull request

## 🎯 Development Guidelines

### Code Style
- Follow Dart/Flutter conventions
- Use meaningful variable and function names
- Add comments for complex logic
- Keep functions small and focused
- Use proper error handling

### File Structure
\`\`\`
lib/
├── main.dart
├── models/          # Data models
├── providers/       # State management
├── screens/         # UI screens
├── services/        # API and business logic
├── widgets/         # Reusable UI components
└── theme/          # App theming
\`\`\`

### Commit Messages
Use conventional commit format:
- `feat: add new feature`
- `fix: resolve bug`
- `docs: update documentation`
- `style: formatting changes`
- `refactor: code restructuring`
- `test: add or update tests`

### Testing
- Write unit tests for new features
- Test on multiple devices/screen sizes
- Verify dark/light theme compatibility
- Test offline functionality

## 🔧 API Integration

### Adding New Data Sources
1. Create service class in `lib/services/`
2. Implement error handling and caching
3. Add rate limiting if needed
4. Update documentation

### Price Data Guidelines
- Use RuneScape Wiki API as primary source
- Implement proper caching (5-15 minutes)
- Handle API failures gracefully
- Respect rate limits

## 🎨 UI/UX Guidelines

### Design Principles
- Maintain OSRS-inspired theme
- Ensure accessibility compliance
- Support both dark and light modes
- Keep interfaces intuitive and clean

### Adding New Screens
1. Create screen file in `lib/screens/`
2. Add navigation in `home_screen.dart`
3. Update bottom navigation if needed
4. Test on various screen sizes

## 📊 Data Management

### Adding Money-Making Methods
1. Update `assets/data/moneymakers.json`
2. Include all required fields
3. Provide accurate profit estimates
4. Add step-by-step instructions
5. Specify requirements clearly

### Goal System
- Support various goal types
- Implement progress tracking
- Add completion celebrations
- Allow custom goals

## 🚦 Pull Request Process

1. **Before Submitting**
   - Test thoroughly on multiple devices
   - Update documentation if needed
   - Add/update tests
   - Follow code style guidelines

2. **PR Description**
   - Clear title and description
   - Link related issues
   - List changes made
   - Include screenshots for UI changes

3. **Review Process**
   - Address reviewer feedback
   - Keep discussions constructive
   - Update PR as needed

## 🏷️ Release Process

### Version Numbering
- Follow semantic versioning (MAJOR.MINOR.PATCH)
- Update version in `pubspec.yaml`
- Tag releases in Git

### Release Notes
- Document new features
- List bug fixes
- Note breaking changes
- Thank contributors

## 🤝 Community Guidelines

### Code of Conduct
- Be respectful and inclusive
- Help newcomers learn
- Provide constructive feedback
- Focus on the code, not the person

### Communication
- Use GitHub Issues for bugs/features
- Join Discord for general discussion
- Be patient with response times
- Provide clear, detailed information

## 📚 Resources

### Documentation
- [Flutter Documentation](https://flutter.dev/docs)
- [Dart Language Guide](https://dart.dev/guides)
- [RuneScape Wiki API](https://oldschool.runescape.wiki/w/Application_programming_interface)

### Tools
- [Flutter Inspector](https://flutter.dev/docs/development/tools/flutter-inspector)
- [Dart DevTools](https://dart.dev/tools/dart-devtools)
- [Android Studio](https://developer.android.com/studio)
- [VS Code Flutter Extension](https://marketplace.visualstudio.com/items?itemName=Dart-Code.flutter)

## 🎉 Recognition

Contributors will be:
- Listed in the app's credits
- Mentioned in release notes
- Added to the GitHub contributors list
- Invited to the contributors Discord channel

Thank you for helping make RuneProfit better for the OSRS community! 🎮
