import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'package:runeprofit/models/goal.dart';
import 'package:runeprofit/services/storage_service.dart';

class GoalService {
  static final GoalService _instance = GoalService._internal();
  
  factory GoalService() {
    return _instance;
  }
  
  GoalService._internal();
  
  final StorageService _storage = StorageService();
  final String _goalsKey = 'user_goals';
  final _uuid = const Uuid();
  
  Future<List<Goal>> getGoals() async {
    final goalsJson = _storage.getData(_goalsKey);
    if (goalsJson == null) {
      return [];
    }
    
    final List<dynamic> jsonList = jsonDecode(goalsJson);
    return jsonList.map((json) => Goal.fromJson(json)).toList();
  }
  
  Future<void> saveGoals(List<Goal> goals) async {
    final jsonList = goals.map((goal) => goal.toJson()).toList();
    await _storage.saveData(_goalsKey, jsonEncode(jsonList));
  }
  
  Future<Goal> addGoal(Goal goal) async {
    final goals = await getGoals();
    
    // Generate ID if not provided
    final newGoal = goal.id.isEmpty 
        ? Goal(
            id: _uuid.v4(),
            name: goal.name,
            description: goal.description,
            type: goal.type,
            currentProgress: goal.currentProgress,
            targetProgress: goal.targetProgress,
            imageUrl: goal.imageUrl,
            completed: goal.completed,
          )
        : goal;
    
    goals.add(newGoal);
    await saveGoals(goals);
    return newGoal;
  }
  
  Future<void> updateGoal(Goal goal) async {
    final goals = await getGoals();
    final index = goals.indexWhere((g) => g.id == goal.id);
    
    if (index != -1) {
      goals[index] = goal;
      await saveGoals(goals);
    }
  }
  
  Future<void> deleteGoal(String goalId) async {
    final goals = await getGoals();
    goals.removeWhere((goal) => goal.id == goalId);
    await saveGoals(goals);
  }
  
  Future<void> updateGoalProgress(String goalId, int progress) async {
    final goals = await getGoals();
    final index = goals.indexWhere((g) => g.id == goalId);
    
    if (index != -1) {
      final goal = goals[index];
      final updatedGoal = goal.copyWith(
        currentProgress: progress,
        completed: progress >= goal.targetProgress,
      );
      
      goals[index] = updatedGoal;
      await saveGoals(goals);
    }
  }
}
