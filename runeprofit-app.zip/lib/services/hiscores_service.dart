import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/services/api_service.dart';

class HiscoresService {
  static final HiscoresService _instance = HiscoresService._internal();
  
  factory HiscoresService() {
    return _instance;
  }
  
  HiscoresService._internal();
  
  final List<String> _skillNames = [
    'overall', 'attack', 'defence', 'strength', 'hitpoints', 'ranged', 'prayer',
    'magic', 'cooking', 'woodcutting', 'fletching', 'fishing', 'firemaking',
    'crafting', 'smithing', 'mining', 'herblore', 'agility', 'thieving',
    'slayer', 'farming', 'runecraft', 'hunter', 'construction'
  ];
  
  Future<PlayerStats?> getPlayerStats(String username) async {
    try {
      final hiscoreData = await ApiService.getPlayerHiscores(username);
      return _parseHiscoreData(hiscoreData);
    } catch (e) {
      print('Error fetching player stats: $e');
      return null;
    }
  }
  
  PlayerStats _parseHiscoreData(String data) {
    final lines = data.split('\n');
    final Map<String, int> skills = {};
    final Map<String, int> experience = {};
    final Map<String, int> virtualLevels = {};
    
    for (int i = 0; i < lines.length && i < _skillNames.length; i++) {
      final parts = lines[i].split(',');
      if (parts.length >= 3) {
        final skillName = _skillNames[i];
        if (skillName != 'overall') {
          final level = int.tryParse(parts[1]) ?? 1;
          final xp = int.tryParse(parts[2]) ?? 0;
          
          skills[skillName] = level;
          experience[skillName] = xp;
          virtualLevels[skillName] = _calculateVirtualLevel(xp);
        }
      }
    }
    
    return PlayerStats(
      skills: skills,
      experience: experience,
      virtualLevels: virtualLevels,
      username: '',
      lastUpdated: DateTime.now(),
    );
  }
  
  int _calculateVirtualLevel(int experience) {
    if (experience < 13034431) {
      // Use standard level calculation for levels 1-99
      return _getLevel(experience);
    }
    
    // Virtual level calculation for 99+
    int level = 99;
    int xpForLevel = 13034431; // XP for level 99
    
    while (xpForLevel < experience && level < 126) {
      level++;
      xpForLevel += (level - 1) * 300;
    }
    
    return level;
  }
  
  int _getLevel(int experience) {
    if (experience <= 0) return 1;
    
    int level = 1;
    int xpForLevel = 0;
    
    while (xpForLevel <= experience && level < 99) {
      level++;
      xpForLevel += (int)((level - 1 + 300 * Math.pow(2, (level - 1) / 7.0)) / 4);
    }
    
    return level - 1;
  }
}
