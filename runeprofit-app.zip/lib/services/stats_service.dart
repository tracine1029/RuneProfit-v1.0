import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/services/storage_service.dart';

class StatsService {
  static final StatsService _instance = StatsService._internal();
  
  factory StatsService() {
    return _instance;
  }
  
  StatsService._internal();
  
  final StorageService _storage = StorageService();
  final String _statsKey = 'player_stats';
  
  Future<PlayerStats?> getPlayerStats() async {
    final statsJson = _storage.getData(_statsKey);
    if (statsJson == null) {
      return null;
    }
    
    return PlayerStats.fromJson(jsonDecode(statsJson));
  }
  
  Future<void> savePlayerStats(PlayerStats stats) async {
    await _storage.saveData(_statsKey, jsonEncode(stats.toJson()));
  }
  
  Future<PlayerStats?> importFromRuneLite(File file) async {
    try {
      final String content = await file.readAsString();
      final Map<String, dynamic> json = jsonDecode(content);
      
      // Extract relevant stats from RuneLite export
      final Map<String, int> skills = {};
      final Map<String, int> experience = {};
      final Map<String, int> virtualLevels = {};
      
      // Process the RuneLite JSON format
      // This would need to be adjusted based on the actual format
      if (json.containsKey('skills')) {
        final skillsData = json['skills'] as Map<String, dynamic>;
        
        skillsData.forEach((key, value) {
          if (value is Map<String, dynamic>) {
            skills[key] = value['level'] ?? 1;
            experience[key] = value['xp'] ?? 0;
            virtualLevels[key] = value['virtualLevel'] ?? skills[key];
          }
        });
      }
      
      final playerStats = PlayerStats(
        skills: skills,
        experience: experience,
        virtualLevels: virtualLevels,
      );
      
      await savePlayerStats(playerStats);
      return playerStats;
    } catch (e) {
      print('Error importing RuneLite data: $e');
      return null;
    }
  }
}
