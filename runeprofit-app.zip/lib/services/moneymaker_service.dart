import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:runeprofit/models/moneymaker.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/services/api_service.dart';

class MoneymakerService {
  static final MoneymakerService _instance = MoneymakerService._internal();
  
  factory MoneymakerService() {
    return _instance;
  }
  
  MoneymakerService._internal();
  
  List<Moneymaker> _cachedMoneymakers = [];
  DateTime? _lastFetched;
  
  Future<List<Moneymaker>> getMoneymakers({
    bool ironmanOnly = false,
    PlayerStats? playerStats,
  }) async {
    // Check if we need to refresh the cache (older than 1 hour)
    final now = DateTime.now();
    if (_cachedMoneymakers.isEmpty || 
        _lastFetched == null || 
        now.difference(_lastFetched!).inHours >= 1) {
      await _fetchMoneymakers();
    }
    
    // Filter by ironman mode if needed
    List<Moneymaker> filteredMoneymakers = _cachedMoneymakers;
    if (ironmanOnly) {
      filteredMoneymakers = filteredMoneymakers.where((mm) => mm.ironmanFriendly).toList();
    }
    
    // Filter by player stats if available
    if (playerStats != null) {
      filteredMoneymakers = filteredMoneymakers.where((mm) {
        // Check if player meets skill requirements
        for (final entry in mm.skillRequirements.entries) {
          final skillName = entry.key;
          final requiredLevel = entry.value;
          final playerLevel = playerStats.skills[skillName] ?? 1;
          
          if (playerLevel < requiredLevel) {
            return false;
          }
        }
        return true;
      }).toList();
    }
    
    // Update GP/hour with current prices
    await _updateProfitability(filteredMoneymakers);
    
    // Sort by GP per hour (highest first)
    filteredMoneymakers.sort((a, b) => b.gpPerHour.compareTo(a.gpPerHour));
    
    return filteredMoneymakers;
  }
  
  Future<void> _fetchMoneymakers() async {
    try {
      // Load base moneymaker data
      final String jsonData = await rootBundle.loadString('assets/data/moneymakers.json');
      final List<dynamic> jsonList = jsonDecode(jsonData);
      
      _cachedMoneymakers = jsonList.map((json) => Moneymaker.fromJson(json)).toList();
      _lastFetched = DateTime.now();
    } catch (e) {
      print('Error fetching moneymakers: $e');
      _cachedMoneymakers = _getDefaultMoneymakers();
    }
  }
  
  Future<void> _updateProfitability(List<Moneymaker> moneymakers) async {
    try {
      final prices = await ApiService.getLatestPrices();
      final priceData = prices['data'] as Map<String, dynamic>? ?? {};
      
      for (final moneymaker in moneymakers) {
        // Update profit calculations based on current prices
        int updatedProfit = moneymaker.gpPerHour;
        
        // Example: Update Vorkath profit based on current drop prices
        if (moneymaker.id == 'vorkath') {
          updatedProfit = _calculateVorkathProfit(priceData);
        } else if (moneymaker.id == 'zulrah') {
          updatedProfit = _calculateZulrahProfit(priceData);
        } else if (moneymaker.id == 'blood_runes') {
          updatedProfit = _calculateBloodRuneProfit(priceData);
        }
        
        // Update the moneymaker's profit
        moneymaker.gpPerHour = updatedProfit;
      }
    } catch (e) {
      print('Error updating profitability: $e');
    }
  }
  
  int _calculateVorkathProfit(Map<String, dynamic> prices) {
    // Vorkath average loot calculation
    final dragonBones = prices['536']?['high'] ?? 2800; // Dragon bones
    final dragonhide = prices['1753']?['high'] ?? 2000; // Blue dragonhide
    final wrath = prices['21880']?['high'] ?? 15000; // Wrath rune
    
    // Average loot per kill (simplified)
    final avgLoot = (dragonBones * 2) + (dragonhide * 2) + (wrath * 20 * 0.1);
    final killsPerHour = 25; // Average kills per hour
    final supplyCost = 50000; // Supplies per hour
    
    return ((avgLoot * killsPerHour) - supplyCost).round();
  }
  
  int _calculateZulrahProfit(Map<String, dynamic> prices) {
    // Zulrah profit calculation
    final scales = prices['12934']?['high'] ?? 180; // Zulrah's scales
    final magicLogs = prices['1513']?['high'] ?? 1000; // Magic logs
    
    final avgLoot = (scales * 200) + (magicLogs * 25 * 0.3);
    final killsPerHour = 20;
    final supplyCost = 80000;
    
    return ((avgLoot * killsPerHour) - supplyCost).round();
  }
  
  int _calculateBloodRuneProfit(Map<String, dynamic> prices) {
    // Blood rune crafting profit
    final bloodRune = prices['565']?['high'] ?? 400; // Blood rune
    final runesPerHour = 3000; // Approximate runes per hour
    
    return (bloodRune * runesPerHour).round();
  }
  
  List<Moneymaker> _getDefaultMoneymakers() {
    return [
      Moneymaker(
        id: 'vorkath',
        name: 'Killing Vorkath',
        description: 'High-level dragon boss with consistent drops and rare uniques.',
        gpPerHour: 3000000,
        skillRequirements: {'ranged': 80, 'defence': 75, 'hitpoints': 75},
        itemRequirements: ['Dragon hunter crossbow', 'Void knight equipment', 'Salve amulet (ei)'],
        steps: [
          'Complete Dragon Slayer II quest',
          'Gear up with ranged equipment',
          'Use super antifire and antivenom+',
          'Use quick-travel to Vorkath',
          'Kill using woox walk method'
        ],
        ironmanFriendly: false,
        imageUrl: '',
        difficulty: 'Very Hard',
        category: 'Combat',
        requirements: ['Dragon Slayer II quest'],
      ),
      Moneymaker(
        id: 'blood_runes',
        name: 'Crafting Blood Runes',
        description: 'AFK runecrafting method with high profit margins.',
        gpPerHour: 1200000,
        skillRequirements: {'runecraft': 77, 'mining': 38, 'crafting': 38},
        itemRequirements: ['Chisel', 'Pickaxe'],
        steps: [
          'Mine dense essence blocks',
          'Chisel into fragments',
          'Use Dark Altar',
          'Craft at Blood Altar'
        ],
        ironmanFriendly: true,
        imageUrl: '',
        difficulty: 'Medium',
        category: 'Skilling',
        requirements: ['77 Runecraft'],
      ),
    ];
  }
}
