import 'dart:convert';
import 'package:runeprofit/models/flip.dart';
import 'package:runeprofit/services/storage_service.dart';
import 'package:runeprofit/services/api_service.dart';

class FlipService {
  static final FlipService _instance = FlipService._internal();
  
  factory FlipService() {
    return _instance;
  }
  
  FlipService._internal();
  
  final StorageService _storage = StorageService();
  final String _cacheKey = 'cached_flips';
  final String _lastFetchedKey = 'flips_last_fetched';
  
  Future<List<Flip>> getFlips() async {
    // Check if we need to refresh the cache (older than 5 minutes)
    final lastFetchedStr = _storage.getData(_lastFetchedKey);
    final now = DateTime.now();
    DateTime? lastFetched;
    
    if (lastFetchedStr != null) {
      lastFetched = DateTime.parse(lastFetchedStr);
    }
    
    if (lastFetched == null || now.difference(lastFetched).inMinutes >= 5) {
      return await _fetchFlips();
    }
    
    // Return cached data
    final cachedData = _storage.getData(_cacheKey);
    if (cachedData != null) {
      final List<dynamic> jsonList = jsonDecode(cachedData);
      return jsonList.map((json) => Flip.fromJson(json)).toList();
    }
    
    // If no cached data, fetch fresh data
    return await _fetchFlips();
  }
  
  Future<List<Flip>> _fetchFlips() async {
    try {
      // Get latest prices and 5-minute data
      final latestPrices = await ApiService.getLatestPrices();
      final fiveMinPrices = await ApiService.get5MinPrices();
      final itemMapping = await ApiService.getItemMapping();
      final volumeData = await ApiService.getVolumeData();
      
      final List<Flip> flips = [];
      
      // Process high-volume, profitable items
      final profitableItems = _findProfitableItems(
        latestPrices, 
        fiveMinPrices, 
        itemMapping, 
        volumeData
      );
      
      for (final item in profitableItems) {
        final flip = Flip(
          id: item['id'].toString(),
          itemName: item['name'],
          buyPrice: item['buyPrice'],
          sellPrice: item['sellPrice'],
          potentialProfit: item['profit'],
          volume: item['volume'],
          imageUrl: 'https://oldschool.runescape.wiki/images/${Uri.encodeComponent(item['name'].replaceAll(' ', '_'))}.png',
          lastUpdated: DateTime.now(),
          profitMargin: item['profitMargin'],
          roi: item['roi'],
        );
        flips.add(flip);
      }
      
      // Sort by profit potential
      flips.sort((a, b) => b.potentialProfit.compareTo(a.potentialProfit));
      
      // Cache the results
      final jsonList = flips.map((flip) => flip.toJson()).toList();
      await _storage.saveData(_cacheKey, jsonEncode(jsonList));
      await _storage.saveData(_lastFetchedKey, DateTime.now().toIso8601String());
      
      return flips.take(50).toList(); // Return top 50 flips
    } catch (e) {
      print('Error fetching flips: $e');
      
      // If there's an error, try to return cached data
      final cachedData = _storage.getData(_cacheKey);
      if (cachedData != null) {
        final List<dynamic> jsonList = jsonDecode(cachedData);
        return jsonList.map((json) => Flip.fromJson(json)).toList();
      }
      
      // If no cached data, return empty list
      return [];
    }
  }
  
  List<Map<String, dynamic>> _findProfitableItems(
    Map<String, dynamic> latest,
    Map<String, dynamic> fiveMin,
    Map<String, dynamic> mapping,
    Map<String, dynamic> volumes,
  ) {
    final List<Map<String, dynamic>> profitable = [];
    
    final latestData = latest['data'] as Map<String, dynamic>? ?? {};
    final fiveMinData = fiveMin['data'] as Map<String, dynamic>? ?? {};
    final volumeData = volumes['data'] as Map<String, dynamic>? ?? {};
    
    for (final entry in latestData.entries) {
      final itemId = entry.key;
      final itemData = entry.value as Map<String, dynamic>? ?? {};
      
      final highPrice = itemData['high'];
      final lowPrice = itemData['low'];
      
      if (highPrice != null && lowPrice != null && highPrice > lowPrice) {
        final profit = highPrice - lowPrice;
        final profitMargin = (profit / lowPrice * 100);
        final roi = (profit / lowPrice * 100);
        
        // Get volume data
        final volume = volumeData[itemId]?['volume'] ?? 0;
        
        // Filter for profitable items with good volume
        if (profit > 100 && profitMargin > 2 && volume > 100) {
          final itemName = mapping[itemId]?['name'] ?? 'Unknown Item';
          
          profitable.add({
            'id': itemId,
            'name': itemName,
            'buyPrice': lowPrice,
            'sellPrice': highPrice,
            'profit': profit,
            'profitMargin': profitMargin.toDouble(),
            'roi': roi.toDouble(),
            'volume': volume,
          });
        }
      }
    }
    
    return profitable;
  }
}
