import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _baseUrl = 'https://prices.runescape.wiki/api/v1/osrs';
  static const String _itemsUrl = 'https://chisel.weirdgloop.org/gazproj/gazbot/os_dump.json';
  static const String _hiscoresUrl = 'https://secure.runescape.com/m=hiscore_oldschool/index_lite.ws';
  
  static final Map<String, String> _headers = {
    'User-Agent': 'RuneProfit App - Contact: your-email@example.com',
    'Content-Type': 'application/json',
  };

  // Get latest item prices
  static Future<Map<String, dynamic>> getLatestPrices() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/latest'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load prices: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get 5-minute price data
  static Future<Map<String, dynamic>> get5MinPrices() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/5m'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load 5m prices: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get item mapping (ID to name)
  static Future<Map<String, dynamic>> getItemMapping() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/mapping'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load item mapping: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get detailed item information
  static Future<Map<String, dynamic>> getItemDetails() async {
    try {
      final response = await http.get(
        Uri.parse(_itemsUrl),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load item details: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get player stats from hiscores
  static Future<String> getPlayerHiscores(String username) async {
    try {
      final response = await http.get(
        Uri.parse('$_hiscoresUrl?player=${Uri.encodeComponent(username)}'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return response.body;
      } else {
        throw Exception('Player not found or hiscores unavailable');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get volume data for items
  static Future<Map<String, dynamic>> getVolumeData() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/volumes'),
        headers: _headers,
      );
      
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to load volume data: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}
