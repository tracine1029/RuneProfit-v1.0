class PlayerStats {
  final Map<String, int> skills;
  final Map<String, int> virtualLevels;
  final Map<String, int> experience;
  final String username;
  final DateTime lastUpdated;
  
  PlayerStats({
    required this.skills,
    required this.virtualLevels,
    required this.experience,
    this.username = '',
    DateTime? lastUpdated,
  }) : lastUpdated = lastUpdated ?? DateTime.now();
  
  factory PlayerStats.fromJson(Map<String, dynamic> json) {
    return PlayerStats(
      skills: Map<String, int>.from(json['skills'] ?? {}),
      virtualLevels: Map<String, int>.from(json['virtualLevels'] ?? {}),
      experience: Map<String, int>.from(json['experience'] ?? {}),
      username: json['username'] ?? '',
      lastUpdated: json['lastUpdated'] != null 
          ? DateTime.parse(json['lastUpdated'])
          : DateTime.now(),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'skills': skills,
      'virtualLevels': virtualLevels,
      'experience': experience,
      'username': username,
      'lastUpdated': lastUpdated.toIso8601String(),
    };
  }
  
  int get totalLevel {
    return skills.values.fold(0, (sum, level) => sum + level);
  }
  
  int get combatLevel {
    final attack = skills['attack'] ?? 1;
    final strength = skills['strength'] ?? 1;
    final defence = skills['defence'] ?? 1;
    final hitpoints = skills['hitpoints'] ?? 10;
    final ranged = skills['ranged'] ?? 1;
    final magic = skills['magic'] ?? 1;
    final prayer = skills['prayer'] ?? 1;
    
    final base = 0.25 * (defence + hitpoints + (prayer / 2).floor());
    final melee = 0.325 * (attack + strength);
    final ranger = 0.325 * ((ranged * 3) / 2).floor();
    final mage = 0.325 * ((magic * 3) / 2).floor();
    
    return (base + [melee, ranger, mage].reduce((a, b) => a > b ? a : b)).floor();
  }
}
