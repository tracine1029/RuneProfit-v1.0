enum GoalType {
  item,
  skill,
  quest,
  achievement,
  custom,
}

class Goal {
  final String id;
  final String name;
  final String description;
  final GoalType type;
  final int currentProgress;
  final int targetProgress;
  final String imageUrl;
  final bool completed;
  
  Goal({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    required this.currentProgress,
    required this.targetProgress,
    required this.imageUrl,
    this.completed = false,
  });
  
  factory Goal.fromJson(Map<String, dynamic> json) {
    return Goal(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      type: GoalType.values.firstWhere(
        (e) => e.toString() == 'GoalType.${json['type']}',
        orElse: () => GoalType.custom,
      ),
      currentProgress: json['currentProgress'],
      targetProgress: json['targetProgress'],
      imageUrl: json['imageUrl'] ?? '',
      completed: json['completed'] ?? false,
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'type': type.toString().split('.').last,
      'currentProgress': currentProgress,
      'targetProgress': targetProgress,
      'imageUrl': imageUrl,
      'completed': completed,
    };
  }
  
  Goal copyWith({
    String? id,
    String? name,
    String? description,
    GoalType? type,
    int? currentProgress,
    int? targetProgress,
    String? imageUrl,
    bool? completed,
  }) {
    return Goal(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      type: type ?? this.type,
      currentProgress: currentProgress ?? this.currentProgress,
      targetProgress: targetProgress ?? this.targetProgress,
      imageUrl: imageUrl ?? this.imageUrl,
      completed: completed ?? this.completed,
    );
  }
}
