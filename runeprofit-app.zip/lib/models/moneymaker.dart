class Moneymaker {
  final String id;
  final String name;
  final String description;
  int gpPerHour;
  final Map<String, int> skillRequirements;
  final List<String> itemRequirements;
  final List<String> steps;
  final bool ironmanFriendly;
  final String imageUrl;
  final String difficulty;
  final String category;
  final List<String> requirements;
  
  Moneymaker({
    required this.id,
    required this.name,
    required this.description,
    required this.gpPerHour,
    required this.skillRequirements,
    required this.itemRequirements,
    required this.steps,
    required this.ironmanFriendly,
    required this.imageUrl,
    this.difficulty = 'Medium',
    this.category = 'General',
    this.requirements = const [],
  });
  
  factory Moneymaker.fromJson(Map<String, dynamic> json) {
    return Moneymaker(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      gpPerHour: json['gpPerHour'],
      skillRequirements: Map<String, int>.from(json['skillRequirements'] ?? {}),
      itemRequirements: List<String>.from(json['itemRequirements'] ?? []),
      steps: List<String>.from(json['steps'] ?? []),
      ironmanFriendly: json['ironmanFriendly'] ?? false,
      imageUrl: json['imageUrl'] ?? '',
      difficulty: json['difficulty'] ?? 'Medium',
      category: json['category'] ?? 'General',
      requirements: List<String>.from(json['requirements'] ?? []),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'gpPerHour': gpPerHour,
      'skillRequirements': skillRequirements,
      'itemRequirements': itemRequirements,
      'steps': steps,
      'ironmanFriendly': ironmanFriendly,
      'imageUrl': imageUrl,
      'difficulty': difficulty,
      'category': category,
      'requirements': requirements,
    };
  }
}
