class Flip {
  final String id;
  final String itemName;
  final int buyPrice;
  final int sellPrice;
  final int potentialProfit;
  final int volume;
  final String imageUrl;
  final DateTime lastUpdated;
  final double profitMargin;
  final double roi;
  
  Flip({
    required this.id,
    required this.itemName,
    required this.buyPrice,
    required this.sellPrice,
    required this.potentialProfit,
    required this.volume,
    required this.imageUrl,
    required this.lastUpdated,
    this.profitMargin = 0.0,
    this.roi = 0.0,
  });
  
  factory Flip.fromJson(Map<String, dynamic> json) {
    return Flip(
      id: json['id'],
      itemName: json['itemName'],
      buyPrice: json['buyPrice'],
      sellPrice: json['sellPrice'],
      potentialProfit: json['potentialProfit'],
      volume: json['volume'],
      imageUrl: json['imageUrl'] ?? '',
      lastUpdated: DateTime.parse(json['lastUpdated']),
      profitMargin: (json['profitMargin'] ?? 0.0).toDouble(),
      roi: (json['roi'] ?? 0.0).toDouble(),
    );
  }
  
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'itemName': itemName,
      'buyPrice': buyPrice,
      'sellPrice': sellPrice,
      'potentialProfit': potentialProfit,
      'volume': volume,
      'imageUrl': imageUrl,
      'lastUpdated': lastUpdated.toIso8601String(),
      'profitMargin': profitMargin,
      'roi': roi,
    };
  }
}
