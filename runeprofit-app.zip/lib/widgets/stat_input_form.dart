import 'package:flutter/material.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/services/stats_service.dart';

class StatInputForm extends StatefulWidget {
  final Function(PlayerStats) onSave;
  
  const StatInputForm({
    Key? key,
    required this.onSave,
  }) : super(key: key);

  @override
  State<StatInputForm> createState() => _StatInputFormState();
}

class _StatInputFormState extends State<StatInputForm> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController> _controllers = {};
  
  final List<String> _skills = [
    'attack', 'strength', 'defence', 'ranged', 'prayer', 'magic',
    'runecraft', 'construction', 'hitpoints', 'agility', 'herblore',
    'thieving', 'crafting', 'fletching', 'slayer', 'hunter',
    'mining', 'smithing', 'fishing', 'cooking', 'firemaking',
    'woodcutting', 'farming',
  ];

  @override
  void initState() {
    super.initState();
    
    // Initialize controllers for each skill
    for (final skill in _skills) {
      _controllers[skill] = TextEditingController(text: '1');
    }
  }

  @override
  void dispose() {
    // Dispose all controllers
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          const Text(
            'Enter your skill levels',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Grid of skill inputs
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              childAspectRatio: 3,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: _skills.length,
            itemBuilder: (context, index) {
              final skill = _skills[index];
              return _buildSkillInput(skill);
            },
          ),
          
          const SizedBox(height: 20),
          
          // Save button
          ElevatedButton(
            onPressed: _saveStats,
            child: const Text('Save Stats'),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSkillInput(String skill) {
    return Row(
      children: [
        // Skill icon (would be an image in a real app)
        Container(
          width: 24,
          height: 24,
          color: Colors.grey.shade300,
          child: Center(
            child: Text(
              skill[0].toUpperCase(),
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ),
        const SizedBox(width: 8),
        
        // Skill input field
        Expanded(
          child: TextFormField(
            controller: _controllers[skill],
            decoration: InputDecoration(
              labelText: skill.capitalize(),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 8,
                vertical: 8,
              ),
            ),
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Required';
              }
              final level = int.tryParse(value);
              if (level == null || level < 1 || level > 99) {
                return 'Invalid';
              }
              return null;
            },
          ),
        ),
      ],
    );
  }
  
  void _saveStats() {
    if (_formKey.currentState!.validate()) {
      // Create maps for the PlayerStats object
      final Map<String, int> skills = {};
      final Map<String, int> virtualLevels = {};
      final Map<String, int> experience = {};
      
      // Populate the maps with values from controllers
      for (final skill in _skills) {
        final level = int.parse(_controllers[skill]!.text);
        skills[skill] = level;
        virtualLevels[skill] = level;
        
        // Approximate XP based on level (simplified)
        experience[skill] = _calculateXpForLevel(level);
      }
      
      // Create PlayerStats object
      final playerStats = PlayerStats(
        skills: skills,
        virtualLevels: virtualLevels,
        experience: experience,
      );
      
      // Save stats and call the callback
      final statsService = StatsService();
      statsService.savePlayerStats(playerStats);
      widget.onSave(playerStats);
    }
  }
  
  int _calculateXpForLevel(int level) {
    // Simplified XP calculation (not accurate to OSRS formula)
    // In a real app, you would use the actual formula
    return (level * level * 100);
  }
}

// Extension to capitalize first letter of a string
extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
