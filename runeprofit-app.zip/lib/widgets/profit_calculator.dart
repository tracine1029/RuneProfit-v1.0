import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class ProfitCalculator extends StatefulWidget {
  const ProfitCalculator({Key? key}) : super(key: key);

  @override
  State<ProfitCalculator> createState() => _ProfitCalculatorState();
}

class _ProfitCalculatorState extends State<ProfitCalculator> {
  final TextEditingController _buyPriceController = TextEditingController();
  final TextEditingController _sellPriceController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController(text: '1');
  final TextEditingController _taxController = TextEditingController(text: '1');
  
  int _profit = 0;
  double _profitMargin = 0.0;
  double _roi = 0.0;
  
  @override
  void initState() {
    super.initState();
    _buyPriceController.addListener(_calculateProfit);
    _sellPriceController.addListener(_calculateProfit);
    _quantityController.addListener(_calculateProfit);
    _taxController.addListener(_calculateProfit);
  }
  
  @override
  void dispose() {
    _buyPriceController.dispose();
    _sellPriceController.dispose();
    _quantityController.dispose();
    _taxController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,###');
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Profit Calculator',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            
            // Input fields
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _buyPriceController,
                    decoration: const InputDecoration(
                      labelText: 'Buy Price',
                      prefixText: 'GP ',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextField(
                    controller: _sellPriceController,
                    decoration: const InputDecoration(
                      labelText: 'Sell Price',
                      prefixText: 'GP ',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _quantityController,
                    decoration: const InputDecoration(
                      labelText: 'Quantity',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: TextField(
                    controller: _taxController,
                    decoration: const InputDecoration(
                      labelText: 'GE Tax %',
                      suffixText: '%',
                    ),
                    keyboardType: TextInputType.number,
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 24),
            
            // Results
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _profit > 0 
                    ? Colors.green.withOpacity(0.1)
                    : _profit < 0 
                        ? Colors.red.withOpacity(0.1)
                        : Colors.grey.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _profit > 0 
                      ? Colors.green
                      : _profit < 0 
                          ? Colors.red
                          : Colors.grey,
                ),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Total Profit:'),
                      Text(
                        '${formatter.format(_profit)} GP',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: _profit > 0 
                              ? Colors.green
                              : _profit < 0 
                                  ? Colors.red
                                  : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Profit Margin:'),
                      Text('${_profitMargin.toStringAsFixed(2)}%'),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('ROI:'),
                      Text('${_roi.toStringAsFixed(2)}%'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  void _calculateProfit() {
    final buyPrice = int.tryParse(_buyPriceController.text) ?? 0;
    final sellPrice = int.tryParse(_sellPriceController.text) ?? 0;
    final quantity = int.tryParse(_quantityController.text) ?? 1;
    final taxRate = double.tryParse(_taxController.text) ?? 1.0;
    
    if (buyPrice > 0 && sellPrice > 0 && quantity > 0) {
      final totalBuyPrice = buyPrice * quantity;
      final tax = (sellPrice * quantity * taxRate / 100).round();
      final totalSellPrice = (sellPrice * quantity) - tax;
      
      setState(() {
        _profit = totalSellPrice - totalBuyPrice;
        _profitMargin = buyPrice > 0 ? (_profit / totalBuyPrice * 100) : 0.0;
        _roi = buyPrice > 0 ? (_profit / totalBuyPrice * 100) : 0.0;
      });
    } else {
      setState(() {
        _profit = 0;
        _profitMargin = 0.0;
        _roi = 0.0;
      });
    }
  }
}
