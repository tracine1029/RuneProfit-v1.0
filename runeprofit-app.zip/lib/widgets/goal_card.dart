import 'package:flutter/material.dart';
import 'package:runeprofit/models/goal.dart';
import 'package:runeprofit/services/goal_service.dart';

class GoalCard extends StatelessWidget {
  final Goal goal;
  
  const GoalCard({
    Key? key,
    required this.goal,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final GoalService goalService = GoalService();
    final double progress = goal.targetProgress > 0
        ? goal.currentProgress / goal.targetProgress
        : 0;
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Goal header
            Row(
              children: [
                // Goal icon/image
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: goal.imageUrl.isNotEmpty
                      ? Image.network(
                          goal.imageUrl,
                          errorBuilder: (context, error, stackTrace) {
                            return Icon(
                              _getIconForGoalType(goal.type),
                              color: Colors.grey,
                            );
                          },
                        )
                      : Icon(
                          _getIconForGoalType(goal.type),
                          color: Colors.grey,
                        ),
                ),
                const SizedBox(width: 12),
                // Goal name and type
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        goal.name,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _getGoalTypeString(goal.type),
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
                // Completed badge
                if (goal.completed)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.green.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      'Completed',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
              ],
            ),
            
            // Description
            if (goal.description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(goal.description),
            ],
            
            // Progress bar
            const SizedBox(height: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Progress: ${goal.currentProgress} / ${goal.targetProgress}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    Text(
                      '${(progress * 100).toStringAsFixed(1)}%',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    goal.completed ? Colors.green : Colors.blue,
                  ),
                ),
              ],
            ),
            
            // Update progress buttons
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Decrement button
                OutlinedButton(
                  onPressed: goal.currentProgress > 0
                      ? () {
                          goalService.updateGoalProgress(
                            goal.id,
                            goal.currentProgress - 1,
                          );
                        }
                      : null,
                  child: const Text('-1'),
                ),
                
                // Increment button
                ElevatedButton(
                  onPressed: goal.currentProgress < goal.targetProgress
                      ? () {
                          goalService.updateGoalProgress(
                            goal.id,
                            goal.currentProgress + 1,
                          );
                        }
                      : null,
                  child: const Text('+1'),
                ),
                
                // Complete button
                ElevatedButton(
                  onPressed: !goal.completed
                      ? () {
                          goalService.updateGoalProgress(
                            goal.id,
                            goal.targetProgress,
                          );
                        }
                      : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                  ),
                  child: const Text('Complete'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  IconData _getIconForGoalType(GoalType type) {
    switch (type) {
      case GoalType.item:
        return Icons.inventory;
      case GoalType.skill:
        return Icons.trending_up;
      case GoalType.quest:
        return Icons.book;
      case GoalType.achievement:
        return Icons.emoji_events;
      case GoalType.custom:
        return Icons.flag;
    }
  }
  
  String _getGoalTypeString(GoalType type) {
    switch (type) {
      case GoalType.item:
        return 'Item Goal';
      case GoalType.skill:
        return 'Skill Goal';
      case GoalType.quest:
        return 'Quest Goal';
      case GoalType.achievement:
        return 'Achievement Goal';
      case GoalType.custom:
        return 'Custom Goal';
    }
  }
}
