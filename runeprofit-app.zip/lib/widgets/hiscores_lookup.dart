import 'package:flutter/material.dart';
import 'package:runeprofit/services/hiscores_service.dart';
import 'package:runeprofit/models/player_stats.dart';

class HiscoresLookup extends StatefulWidget {
  final Function(PlayerStats) onStatsLoaded;
  
  const HiscoresLookup({
    Key? key,
    required this.onStatsLoaded,
  }) : super(key: key);

  @override
  State<HiscoresLookup> createState() => _HiscoresLookupState();
}

class _HiscoresLookupState extends State<HiscoresLookup> {
  final TextEditingController _usernameController = TextEditingController();
  final HiscoresService _hiscoresService = HiscoresService();
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _usernameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lookup Player Stats',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'OSRS Username',
                hintText: 'Enter your username',
                prefixIcon: const Icon(Icons.person),
                errorText: _errorMessage,
                enabled: !_isLoading,
              ),
              onSubmitted: (_) => _lookupStats(),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _lookupStats,
                child: _isLoading
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          SizedBox(width: 8),
                          Text('Looking up...'),
                        ],
                      )
                    : const Text('Lookup Stats'),
              ),
            ),
            if (_errorMessage != null) ...[
              const SizedBox(height: 8),
              Text(
                _errorMessage!,
                style: const TextStyle(color: Colors.red),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _lookupStats() async {
    final username = _usernameController.text.trim();
    
    if (username.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a username';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final stats = await _hiscoresService.getPlayerStats(username);
      
      if (stats != null) {
        // Update the stats with the username
        final updatedStats = PlayerStats(
          skills: stats.skills,
          virtualLevels: stats.virtualLevels,
          experience: stats.experience,
          username: username,
          lastUpdated: DateTime.now(),
        );
        
        widget.onStatsLoaded(updatedStats);
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Successfully loaded stats for $username'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        setState(() {
          _errorMessage = 'Player not found or stats unavailable';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error loading stats: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
