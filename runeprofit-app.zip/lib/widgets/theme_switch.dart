import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runeprofit/providers/theme_provider.dart';

class ThemeSwitch extends StatelessWidget {
  const ThemeSwitch({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.brightness_7,
              color: themeProvider.isDarkMode 
                  ? Colors.grey 
                  : Theme.of(context).primaryColor,
              size: 20,
            ),
            const SizedBox(width: 8),
            Switch(
              value: themeProvider.isDarkMode,
              onChanged: (value) {
                if (value) {
                  themeProvider.setThemeMode(ThemeMode.dark);
                } else {
                  themeProvider.setThemeMode(ThemeMode.light);
                }
              },
            ),
            const SizedBox(width: 8),
            Icon(
              Icons.brightness_3,
              color: themeProvider.isDarkMode 
                  ? Theme.of(context).primaryColor 
                  : Colors.grey,
              size: 20,
            ),
          ],
        );
      },
    );
  }
}
