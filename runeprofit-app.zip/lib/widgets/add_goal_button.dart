import 'package:flutter/material.dart';
import 'package:runeprofit/models/goal.dart';
import 'package:runeprofit/services/goal_service.dart';
import 'package:uuid/uuid.dart';

class AddGoalButton extends StatelessWidget {
  final Function(Goal) onGoalAdded;
  
  const AddGoalButton({
    Key? key,
    required this.onGoalAdded,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () => _showAddGoalDialog(context),
      child: const Icon(Icons.add),
    );
  }
  
  void _showAddGoalDialog(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    final nameController = TextEditingController();
    final descriptionController = TextEditingController();
    final targetController = TextEditingController();
    GoalType selectedType = GoalType.custom;
    
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add New Goal'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Name field
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Goal Name',
                      hintText: 'e.g., Get Dragon Armor',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a goal name';
                      }
                      return null;
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Description field
                  TextFormField(
                    controller: descriptionController,
                    decoration: const InputDecoration(
                      labelText: 'Description (Optional)',
                      hintText: 'e.g., Save up for full dragon armor set',
                    ),
                    maxLines: 2,
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Goal type dropdown
                  DropdownButtonFormField<GoalType>(
                    value: selectedType,
                    decoration: const InputDecoration(
                      labelText: 'Goal Type',
                    ),
                    items: GoalType.values.map((type) {
                      return DropdownMenuItem<GoalType>(
                        value: type,
                        child: Text(_getGoalTypeString(type)),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        selectedType = value;
                      }
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Target value field
                  TextFormField(
                    controller: targetController,
                    decoration: const InputDecoration(
                      labelText: 'Target Value',
                      hintText: 'e.g., 1 for completion, or specific amount',
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a target value';
                      }
                      if (int.tryParse(value) == null || int.parse(value) <= 0) {
                        return 'Please enter a valid positive number';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (formKey.currentState!.validate()) {
                  final goalService = GoalService();
                  final goal = Goal(
                    id: const Uuid().v4(),
                    name: nameController.text,
                    description: descriptionController.text,
                    type: selectedType,
                    currentProgress: 0,
                    targetProgress: int.parse(targetController.text),
                    imageUrl: '',
                    completed: false,
                  );
                  
                  final savedGoal = await goalService.addGoal(goal);
                  onGoalAdded(savedGoal);
                  Navigator.of(context).pop();
                }
              },
              child: const Text('Add Goal'),
            ),
          ],
        );
      },
    );
  }
  
  String _getGoalTypeString(GoalType type) {
    switch (type) {
      case GoalType.item:
        return 'Item Goal';
      case GoalType.skill:
        return 'Skill Goal';
      case GoalType.quest:
        return 'Quest Goal';
      case GoalType.achievement:
        return 'Achievement Goal';
      case GoalType.custom:
        return 'Custom Goal';
    }
  }
}
