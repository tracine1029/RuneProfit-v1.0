import 'package:flutter/material.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:intl/intl.dart';

class StatsDisplay extends StatelessWidget {
  final PlayerStats stats;
  
  const StatsDisplay({
    Key? key,
    required this.stats,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,###');
    
    return Column(
      children: [
        // Overview card
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  stats.username.isNotEmpty ? stats.username : 'Your Stats',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildStatSummary('Total Level', stats.totalLevel.toString()),
                    _buildStatSummary('Combat Level', stats.combatLevel.toString()),
                    _buildStatSummary('Skills 99+', _count99s().toString()),
                  ],
                ),
              ],
            ),
          ),
        ),
        
        // Skills grid
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Skills',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    childAspectRatio: 2.5,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: _getDisplaySkills().length,
                  itemBuilder: (context, index) {
                    final skill = _getDisplaySkills()[index];
                    return _buildSkillTile(skill, formatter);
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildStatSummary(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.amber,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
  
  Widget _buildSkillTile(String skill, NumberFormat formatter) {
    final level = stats.skills[skill] ?? 1;
    final xp = stats.experience[skill] ?? 0;
    final virtualLevel = stats.virtualLevels[skill] ?? level;
    
    return Container(
      decoration: BoxDecoration(
        color: level >= 99 ? Colors.amber.withOpacity(0.1) : null,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: level >= 99 ? Colors.amber : Colors.grey.shade300,
          width: level >= 99 ? 2 : 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  level.toString(),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: level >= 99 ? Colors.amber.shade700 : null,
                  ),
                ),
                if (virtualLevel > level) ...[
                  const SizedBox(width: 4),
                  Text(
                    '($virtualLevel)',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ],
              ],
            ),
            Text(
              skill.capitalize(),
              style: const TextStyle(fontSize: 10),
              textAlign: TextAlign.center,
            ),
            if (xp > 0)
              Text(
                formatter.format(xp),
                style: TextStyle(
                  fontSize: 8,
                  color: Colors.grey.shade600,
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  List<String> _getDisplaySkills() {
    return [
      'attack', 'strength', 'defence', 'hitpoints', 'ranged', 'prayer',
      'magic', 'cooking', 'woodcutting', 'fletching', 'fishing', 'firemaking',
      'crafting', 'smithing', 'mining', 'herblore', 'agility', 'thieving',
      'slayer', 'farming', 'runecraft', 'hunter', 'construction'
    ];
  }
  
  int _count99s() {
    return stats.skills.values.where((level) => level >= 99).length;
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
