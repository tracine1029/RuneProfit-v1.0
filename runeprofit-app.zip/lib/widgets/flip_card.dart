import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:runeprofit/models/flip.dart';

class FlipCard extends StatelessWidget {
  final Flip flip;
  
  const FlipCard({
    Key? key,
    required this.flip,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat("#,###");
    final profitPercentage = ((flip.sellPrice - flip.buyPrice) / flip.buyPrice * 100).toStringAsFixed(1);
    
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Item name and image
            Row(
              children: [
                // Item image
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: flip.imageUrl.isNotEmpty
                      ? Image.network(
                          flip.imageUrl,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(Icons.image_not_supported);
                          },
                        )
                      : const Icon(Icons.image),
                ),
                const SizedBox(width: 12),
                // Item name
                Expanded(
                  child: Text(
                    flip.itemName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            
            const SizedBox(height: 16),
            
            // Buy/Sell prices
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Buy price
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Buy for',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                    Text(
                      '${formatter.format(flip.buyPrice)} gp',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                
                // Profit
                Column(
                  children: [
                    const Text(
                      'Profit',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                    Text(
                      '${formatter.format(flip.potentialProfit)} gp',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    Text(
                      '$profitPercentage%',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.green.shade700,
                      ),
                    ),
                  ],
                ),
                
                // Sell price
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      'Sell for',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                    Text(
                      '${formatter.format(flip.sellPrice)} gp',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ],
            ),
            
            const SizedBox(height: 12),
            
            // Volume and last updated
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Volume
                Row(
                  children: [
                    const Icon(
                      Icons.bar_chart,
                      size: 16,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'Volume: ${formatter.format(flip.volume)}/day',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                
                // Last updated
                Row(
                  children: [
                    const Icon(
                      Icons.access_time,
                      size: 16,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'Updated: ${DateFormat.Hm().format(flip.lastUpdated)}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
