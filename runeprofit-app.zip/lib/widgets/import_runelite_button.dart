import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/services/stats_service.dart';

class ImportRuneLiteButton extends StatelessWidget {
  final Function(PlayerStats) onImport;
  
  const ImportRuneLiteButton({
    Key? key,
    required this.onImport,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: () => _importFromRuneLite(context),
      icon: const Icon(Icons.upload_file),
      label: const Text('Import from RuneLite'),
    );
  }
  
  Future<void> _importFromRuneLite(BuildContext context) async {
    try {
      // Open file picker
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );
      
      if (result != null && result.files.single.path != null) {
        final file = File(result.files.single.path!);
        final statsService = StatsService();
        
        // Show loading indicator
        _showLoadingDialog(context);
        
        // Import stats from file
        final stats = await statsService.importFromRuneLite(file);
        
        // Hide loading indicator
        Navigator.of(context).pop();
        
        if (stats != null) {
          onImport(stats);
          _showSuccessDialog(context);
        } else {
          _showErrorDialog(context, 'Failed to import stats. The file format may be invalid.');
        }
      }
    } catch (e) {
      _showErrorDialog(context, 'An error occurred: $e');
    }
  }
  
  void _showLoadingDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return const AlertDialog(
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              const Text('Importing stats...'),
            ],
          ),
        );
      },
    );
  }
  
  void _showSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Success'),
          content: const Text('Stats imported successfully!'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
  
  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
