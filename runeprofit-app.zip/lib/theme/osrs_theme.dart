import 'package:flutter/material.dart';

// OSRS color palette
class OSRSColors {
  // Primary colors
  static const Color primaryBrown = Color(0xFF3E3529);
  static const Color lightBrown = Color(0xFFC5AB81);
  static const Color darkBrown = Color(0xFF2A251A);
  
  // Accent colors
  static const Color gold = Color(0xFFFFD700);
  static const Color amber = Colors.amber;
  
  // Background colors
  static const Color lightBackground = Color(0xFFF8F5F0);
  static const Color darkBackground = Color(0xFF121212);
  static const Color darkSurface = Color(0xFF1E1E1E);
  static const Color darkCard = Color(0xFF2D2D2D);
  
  // Text colors
  static const Color lightText = Color(0xFF212121);
  static const Color darkText = Color(0xFFE0E0E0);
  static const Color mutedText = Color(0xFF757575);
  static const Color darkMutedText = Color(0xFFBDBDBD);
  
  // Status colors
  static const Color success = Color(0xFF4CAF50);
  static const Color warning = Color(0xFFFF9800);
  static const Color error = Color(0xFFF44336);
  static const Color info = Color(0xFF2196F3);
}

// OSRS-themed light theme
final ThemeData osrsTheme = ThemeData(
  brightness: Brightness.light,
  primarySwatch: _createMaterialColor(OSRSColors.primaryBrown),
  primaryColor: OSRSColors.primaryBrown,
  scaffoldBackgroundColor: OSRSColors.lightBackground,
  cardColor: Colors.white,
  dividerColor: Colors.grey.shade300,
  
  // AppBar theme
  appBarTheme: const AppBarTheme(
    backgroundColor: OSRSColors.primaryBrown,
    foregroundColor: Colors.white,
    elevation: 4,
    centerTitle: true,
    titleTextStyle: TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: Colors.white,
    ),
    iconTheme: IconThemeData(color: Colors.white),
  ),
  
  // Card theme
  cardTheme: CardTheme(
    color: Colors.white,
    elevation: 2,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
    ),
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  ),
  
  // Button themes
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: OSRSColors.primaryBrown,
      foregroundColor: Colors.white,
      elevation: 2,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),
  ),
  
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: OSRSColors.primaryBrown,
      side: const BorderSide(color: OSRSColors.primaryBrown),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),
  ),
  
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: OSRSColors.primaryBrown,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    ),
  ),
  
  // Input decoration theme
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey.shade400),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey.shade400),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: OSRSColors.primaryBrown, width: 2),
    ),
    filled: true,
    fillColor: Colors.grey.shade50,
  ),
  
  // Progress indicator theme
  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: OSRSColors.primaryBrown,
  ),
  
  // Switch theme
  switchTheme: SwitchThemeData(
    thumbColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return OSRSColors.gold;
      }
      return Colors.grey.shade400;
    }),
    trackColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return OSRSColors.lightBrown;
      }
      return Colors.grey.shade300;
    }),
  ),
  
  // Color scheme
  colorScheme: ColorScheme.fromSeed(
    seedColor: OSRSColors.primaryBrown,
    brightness: Brightness.light,
    primary: OSRSColors.primaryBrown,
    secondary: OSRSColors.gold,
    surface: Colors.white,
    background: OSRSColors.lightBackground,
    error: OSRSColors.error,
  ),
);

// OSRS-themed dark theme
final ThemeData osrsDarkTheme = ThemeData(
  brightness: Brightness.dark,
  primarySwatch: _createMaterialColor(OSRSColors.lightBrown),
  primaryColor: OSRSColors.lightBrown,
  scaffoldBackgroundColor: OSRSColors.darkBackground,
  cardColor: OSRSColors.darkCard,
  dividerColor: Colors.grey.shade700,
  
  // AppBar theme
  appBarTheme: const AppBarTheme(
    backgroundColor: OSRSColors.darkCard,
    foregroundColor: OSRSColors.gold,
    elevation: 4,
    centerTitle: true,
    titleTextStyle: TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: OSRSColors.gold,
    ),
    iconTheme: IconThemeData(color: OSRSColors.gold),
  ),
  
  // Card theme
  cardTheme: CardTheme(
    color: OSRSColors.darkCard,
    elevation: 4,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
      side: BorderSide(color: Colors.grey.shade800, width: 1),
    ),
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
  ),
  
  // Button themes
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: OSRSColors.lightBrown,
      foregroundColor: OSRSColors.darkBackground,
      elevation: 2,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),
  ),
  
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: OSRSColors.gold,
      side: const BorderSide(color: OSRSColors.gold),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    ),
  ),
  
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: OSRSColors.gold,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    ),
  ),
  
  // Input decoration theme
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey.shade600),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey.shade600),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: OSRSColors.gold, width: 2),
    ),
    filled: true,
    fillColor: OSRSColors.darkSurface,
    labelStyle: const TextStyle(color: OSRSColors.darkText),
    hintStyle: TextStyle(color: Colors.grey.shade500),
  ),
  
  // Progress indicator theme
  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: OSRSColors.gold,
  ),
  
  // Switch theme
  switchTheme: SwitchThemeData(
    thumbColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return OSRSColors.gold;
      }
      return Colors.grey.shade600;
    }),
    trackColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return OSRSColors.lightBrown.withOpacity(0.5);
      }
      return Colors.grey.shade700;
    }),
  ),
  
  // Text theme
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: OSRSColors.darkText),
    bodyMedium: TextStyle(color: OSRSColors.darkText),
    bodySmall: TextStyle(color: OSRSColors.darkMutedText),
    headlineLarge: TextStyle(color: OSRSColors.darkText),
    headlineMedium: TextStyle(color: OSRSColors.darkText),
    headlineSmall: TextStyle(color: OSRSColors.darkText),
    titleLarge: TextStyle(color: OSRSColors.darkText),
    titleMedium: TextStyle(color: OSRSColors.darkText),
    titleSmall: TextStyle(color: OSRSColors.darkText),
  ),
  
  // Color scheme
  colorScheme: ColorScheme.fromSeed(
    seedColor: OSRSColors.lightBrown,
    brightness: Brightness.dark,
    primary: OSRSColors.lightBrown,
    secondary: OSRSColors.gold,
    surface: OSRSColors.darkCard,
    background: OSRSColors.darkBackground,
    error: OSRSColors.error,
    onPrimary: OSRSColors.darkBackground,
    onSecondary: OSRSColors.darkBackground,
    onSurface: OSRSColors.darkText,
    onBackground: OSRSColors.darkText,
  ),
);

// Helper function to create MaterialColor
MaterialColor _createMaterialColor(Color color) {
  List strengths = <double>[.05];
  Map<int, Color> swatch = {};
  final int r = color.red, g = color.green, b = color.blue;

  for (int i = 1; i < 10; i++) {
    strengths.add(0.1 * i);
  }
  
  for (var strength in strengths) {
    final double ds = 0.5 - strength;
    swatch[(strength * 1000).round()] = Color.fromRGBO(
      r + ((ds < 0 ? r : (255 - r)) * ds).round(),
      g + ((ds < 0 ? g : (255 - g)) * ds).round(),
      b + ((ds < 0 ? b : (255 - b)) * ds).round(),
      1,
    );
  }
  
  return MaterialColor(color.value, swatch);
}
