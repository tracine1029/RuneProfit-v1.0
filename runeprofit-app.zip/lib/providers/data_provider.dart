import 'package:flutter/material.dart';
import 'package:runeprofit/models/player_stats.dart';
import 'package:runeprofit/models/moneymaker.dart';
import 'package:runeprofit/models/flip.dart';
import 'package:runeprofit/models/goal.dart';
import 'package:runeprofit/services/stats_service.dart';
import 'package:runeprofit/services/moneymaker_service.dart';
import 'package:runeprofit/services/flip_service.dart';
import 'package:runeprofit/services/goal_service.dart';

class DataProvider extends ChangeNotifier {
  // Services
  final StatsService _statsService = StatsService();
  final MoneymakerService _moneymakerService = MoneymakerService();
  final FlipService _flipService = FlipService();
  final GoalService _goalService = GoalService();

  // Data
  PlayerStats? _playerStats;
  List<Moneymaker> _moneymakers = [];
  List<Flip> _flips = [];
  List<Goal> _goals = [];

  // Loading states
  bool _isLoadingStats = false;
  bool _isLoadingMoneymakers = false;
  bool _isLoadingFlips = false;
  bool _isLoadingGoals = false;

  // Settings
  bool _ironmanMode = false;
  String _lastUpdated = '';

  // Getters
  PlayerStats? get playerStats => _playerStats;
  List<Moneymaker> get moneymakers => _moneymakers;
  List<Flip> get flips => _flips;
  List<Goal> get goals => _goals;
  
  bool get isLoadingStats => _isLoadingStats;
  bool get isLoadingMoneymakers => _isLoadingMoneymakers;
  bool get isLoadingFlips => _isLoadingFlips;
  bool get isLoadingGoals => _isLoadingGoals;
  
  bool get ironmanMode => _ironmanMode;
  String get lastUpdated => _lastUpdated;

  // Initialize data
  Future<void> initialize() async {
    await loadPlayerStats();
    await loadMoneymakers();
    await loadFlips();
    await loadGoals();
  }

  // Stats methods
  Future<void> loadPlayerStats() async {
    _isLoadingStats = true;
    notifyListeners();
    
    try {
      _playerStats = await _statsService.getPlayerStats();
    } catch (e) {
      debugPrint('Error loading stats: $e');
    }
    
    _isLoadingStats = false;
    notifyListeners();
  }

  Future<void> savePlayerStats(PlayerStats stats) async {
    await _statsService.savePlayerStats(stats);
    _playerStats = stats;
    notifyListeners();
    
    // Reload moneymakers based on new stats
    await loadMoneymakers();
  }

  // Moneymaker methods
  Future<void> loadMoneymakers() async {
    _isLoadingMoneymakers = true;
    notifyListeners();
    
    try {
      _moneymakers = await _moneymakerService.getMoneymakers(
        ironmanOnly: _ironmanMode,
        playerStats: _playerStats,
      );
      _lastUpdated = DateTime.now().toIso8601String();
    } catch (e) {
      debugPrint('Error loading moneymakers: $e');
    }
    
    _isLoadingMoneymakers = false;
    notifyListeners();
  }

  void toggleIronmanMode() {
    _ironmanMode = !_ironmanMode;
    notifyListeners();
    loadMoneymakers();
  }

  // Flip methods
  Future<void> loadFlips() async {
    _isLoadingFlips = true;
    notifyListeners();
    
    try {
      _flips = await _flipService.getFlips();
      _lastUpdated = DateTime.now().toIso8601String();
    } catch (e) {
      debugPrint('Error loading flips: $e');
    }
    
    _isLoadingFlips = false;
    notifyListeners();
  }

  // Goal methods
  Future<void> loadGoals() async {
    _isLoadingGoals = true;
    notifyListeners();
    
    try {
      _goals = await _goalService.getGoals();
    } catch (e) {
      debugPrint('Error loading goals: $e');
    }
    
    _isLoadingGoals = false;
    notifyListeners();
  }

  Future<void> addGoal(Goal goal) async {
    try {
      final savedGoal = await _goalService.addGoal(goal);
      _goals.add(savedGoal);
      notifyListeners();
    } catch (e) {
      debugPrint('Error adding goal: $e');
    }
  }

  Future<void> updateGoal(Goal goal) async {
    try {
      await _goalService.updateGoal(goal);
      final index = _goals.indexWhere((g) => g.id == goal.id);
      if (index != -1) {
        _goals[index] = goal;
        notifyListeners();
      }
    } catch (e) {
      debugPrint('Error updating goal: $e');
    }
  }

  Future<void> deleteGoal(String goalId) async {
    try {
      await _goalService.deleteGoal(goalId);
      _goals.removeWhere((goal) => goal.id == goalId);
      notifyListeners();
    } catch (e) {
      debugPrint('Error deleting goal: $e');
    }
  }

  // Refresh all data
  Future<void> refreshAllData() async {
    await Future.wait([
      loadMoneymakers(),
      loadFlips(),
      loadGoals(),
    ]);
  }
}
