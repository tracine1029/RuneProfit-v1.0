import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runeprofit/providers/theme_provider.dart';
import 'package:runeprofit/providers/data_provider.dart';
import 'package:runeprofit/screens/home_screen.dart';
import 'package:runeprofit/services/storage_service.dart';
import 'package:runeprofit/theme/osrs_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize services
  await StorageService().initialize();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ThemeProvider()),
        ChangeNotifierProvider(create: (context) => DataProvider()),
      ],
      child: const RuneProfitApp(),
    ),
  );
}

class RuneProfitApp extends StatelessWidget {
  const RuneProfitApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return MaterialApp(
          title: 'RuneProfit',
          theme: osrsTheme,
          darkTheme: osrsDarkTheme,
          themeMode: themeProvider.themeMode,
          debugShowCheckedModeBanner: false,
          home: const HomeScreen(),
        );
      },
    );
  }
}
