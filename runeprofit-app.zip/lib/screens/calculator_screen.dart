import 'package:flutter/material.dart';
import 'package:runeprofit/widgets/profit_calculator.dart';
import 'package:runeprofit/widgets/theme_toggle_button.dart';

class CalculatorScreen extends StatelessWidget {
  const CalculatorScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculators'),
        actions: const [
          ThemeToggleButton(),
        ],
      ),
      body: const SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            ProfitCalculator(),
            // Add more calculators here in the future
          ],
        ),
      ),
    );
  }
}
