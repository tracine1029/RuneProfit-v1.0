import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runeprofit/providers/data_provider.dart';
import 'package:runeprofit/widgets/stats_display.dart';
import 'package:runeprofit/widgets/stat_input_form.dart';
import 'package:runeprofit/widgets/import_runelite_button.dart';
import 'package:runeprofit/widgets/hiscores_lookup.dart';
import 'package:runeprofit/widgets/theme_toggle_button.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Stats'),
        actions: [
          const ThemeToggleButton(),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              context.read<DataProvider>().loadPlayerStats();
            },
          ),
        ],
      ),
      body: Consumer<DataProvider>(
        builder: (context, dataProvider, child) {
          if (dataProvider.isLoadingStats) {
            return const Center(child: CircularProgressIndicator());
          }
          
          if (dataProvider.playerStats == null) {
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  const Text(
                    'No stats found. Please enter your stats, import from RuneLite, or lookup from hiscores.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 20),
                  
                  // Hiscores lookup
                  HiscoresLookup(
                    onStatsLoaded: (stats) {
                      dataProvider.savePlayerStats(stats);
                    },
                  ),
                  
                  const SizedBox(height: 20),
                  
                  // Manual input
                  StatInputForm(
                    onSave: (stats) {
                      dataProvider.savePlayerStats(stats);
                    },
                  ),
                  
                  const SizedBox(height: 20),
                  
                  // RuneLite import
                  ImportRuneLiteButton(
                    onImport: (stats) {
                      dataProvider.savePlayerStats(stats);
                    },
                  ),
                ],
              ),
            );
          }
          
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                StatsDisplay(stats: dataProvider.playerStats!),
                const SizedBox(height: 16),
                
                // Action buttons
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () {
                          // Show update options
                          _showUpdateOptions(context, dataProvider);
                        },
                        icon: const Icon(Icons.edit),
                        label: const Text('Update Stats'),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          dataProvider.loadPlayerStats();
                        },
                        icon: const Icon(Icons.refresh),
                        label: const Text('Refresh'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
  
  void _showUpdateOptions(BuildContext context, DataProvider dataProvider) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Update Your Stats',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              
              ListTile(
                leading: const Icon(Icons.search),
                title: const Text('Lookup from Hiscores'),
                subtitle: const Text('Get latest stats from OSRS hiscores'),
                onTap: () {
                  Navigator.pop(context);
                  _showHiscoresDialog(context, dataProvider);
                },
              ),
              
              ListTile(
                leading: const Icon(Icons.upload_file),
                title: const Text('Import from RuneLite'),
                subtitle: const Text('Import stats from RuneLite export'),
                onTap: () {
                  Navigator.pop(context);
                  // Show import dialog
                },
              ),
              
              ListTile(
                leading: const Icon(Icons.edit),
                title: const Text('Manual Entry'),
                subtitle: const Text('Manually enter your stats'),
                onTap: () {
                  Navigator.pop(context);
                  // Show manual entry dialog
                },
              ),
            ],
          ),
        );
      },
    );
  }
  
  void _showHiscoresDialog(BuildContext context, DataProvider dataProvider) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Lookup Stats'),
          content: HiscoresLookup(
            onStatsLoaded: (stats) {
              dataProvider.savePlayerStats(stats);
              Navigator.pop(context);
            },
          ),
        );
      },
    );
  }
}
