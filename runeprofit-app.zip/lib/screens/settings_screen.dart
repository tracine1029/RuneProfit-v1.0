import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runeprofit/providers/theme_provider.dart';
import 'package:runeprofit/widgets/theme_switch.dart';
import 'package:runeprofit/services/storage_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        children: [
          // Theme section
          _buildSectionHeader('Appearance'),
          _buildThemeSettings(context),
          
          const Divider(),
          
          // Data section
          _buildSectionHeader('Data'),
          _buildDataSettings(context),
          
          const Divider(),
          
          // About section
          _buildSectionHeader('About'),
          _buildAboutSettings(context),
        ],
      ),
    );
  }
  
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
  
  Widget _buildThemeSettings(BuildContext context) {
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, child) {
        return Column(
          children: [
            ListTile(
              leading: const Icon(Icons.palette),
              title: const Text('Theme'),
              subtitle: Text(_getThemeModeString(themeProvider.themeMode)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showThemeDialog(context, themeProvider),
            ),
            ListTile(
              leading: const Icon(Icons.brightness_6),
              title: const Text('Quick Toggle'),
              subtitle: const Text('Switch between light and dark mode'),
              trailing: const ThemeSwitch(),
            ),
          ],
        );
      },
    );
  }
  
  Widget _buildDataSettings(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.delete_outline),
          title: const Text('Clear All Data'),
          subtitle: const Text('Remove all stored stats, goals, and settings'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showClearDataDialog(context),
        ),
        ListTile(
          leading: const Icon(Icons.download),
          title: const Text('Export Data'),
          subtitle: const Text('Export your data as JSON'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _exportData(context),
        ),
      ],
    );
  }
  
  Widget _buildAboutSettings(BuildContext context) {
    return Column(
      children: [
        ListTile(
          leading: const Icon(Icons.info_outline),
          title: const Text('Version'),
          subtitle: const Text('1.0.0'),
        ),
        ListTile(
          leading: const Icon(Icons.code),
          title: const Text('Open Source'),
          subtitle: const Text('View source code on GitHub'),
          trailing: const Icon(Icons.open_in_new),
          onTap: () {
            // Open GitHub link
          },
        ),
        ListTile(
          leading: const Icon(Icons.bug_report),
          title: const Text('Report Bug'),
          subtitle: const Text('Help us improve the app'),
          trailing: const Icon(Icons.open_in_new),
          onTap: () {
            // Open bug report link
          },
        ),
      ],
    );
  }
  
  void _showThemeDialog(BuildContext context, ThemeProvider themeProvider) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Choose Theme'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              RadioListTile<ThemeMode>(
                title: const Text('System Default'),
                subtitle: const Text('Follow system theme'),
                value: ThemeMode.system,
                groupValue: themeProvider.themeMode,
                onChanged: (value) {
                  if (value != null) {
                    themeProvider.setThemeMode(value);
                    Navigator.of(context).pop();
                  }
                },
              ),
              RadioListTile<ThemeMode>(
                title: const Text('Light'),
                subtitle: const Text('Light theme'),
                value: ThemeMode.light,
                groupValue: themeProvider.themeMode,
                onChanged: (value) {
                  if (value != null) {
                    themeProvider.setThemeMode(value);
                    Navigator.of(context).pop();
                  }
                },
              ),
              RadioListTile<ThemeMode>(
                title: const Text('Dark'),
                subtitle: const Text('Dark theme'),
                value: ThemeMode.dark,
                groupValue: themeProvider.themeMode,
                onChanged: (value) {
                  if (value != null) {
                    themeProvider.setThemeMode(value);
                    Navigator.of(context).pop();
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
          ],
        );
      },
    );
  }
  
  void _showClearDataDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Clear All Data'),
          content: const Text(
            'This will permanently delete all your stats, goals, and settings. This action cannot be undone.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                await StorageService().clearAll();
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('All data cleared successfully'),
                  ),
                );
              },
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              child: const Text('Clear All'),
            ),
          ],
        );
      },
    );
  }
  
  void _exportData(BuildContext context) {
    // Implementation for data export
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export feature coming soon!'),
      ),
    );
  }
  
  String _getThemeModeString(ThemeMode themeMode) {
    switch (themeMode) {
      case ThemeMode.light:
        return 'Light';
      case ThemeMode.dark:
        return 'Dark';
      case ThemeMode.system:
      default:
        return 'System Default';
    }
  }
}
