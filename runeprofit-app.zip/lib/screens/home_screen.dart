import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:runeprofit/providers/data_provider.dart';
import 'package:runeprofit/screens/stats_screen.dart';
import 'package:runeprofit/screens/moneymakers_screen.dart';
import 'package:runeprofit/screens/flips_screen.dart';
import 'package:runeprofit/screens/goals_screen.dart';
import 'package:runeprofit/screens/calculator_screen.dart';
import 'package:runeprofit/screens/settings_screen.dart';
import 'package:runeprofit/widgets/osrs_bottom_nav.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  
  final List<Widget> _screens = [
    const StatsScreen(),
    const MoneymakersScreen(),
    const FlipsScreen(),
    const GoalsScreen(),
    const CalculatorScreen(),
    const SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    // Initialize data when app starts
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DataProvider>().initialize();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark 
              ? const Color(0xFF2D2D2D) 
              : const Color(0xFF3E3529),
          border: Border(
            top: BorderSide(
              color: Theme.of(context).brightness == Brightness.dark 
                  ? Colors.grey.shade700 
                  : Colors.brown.shade800,
              width: 2,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 4,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.transparent,
          selectedItemColor: Colors.amber,
          unselectedItemColor: Theme.of(context).brightness == Brightness.dark 
              ? Colors.grey.shade400 
              : Colors.brown.shade200,
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
          unselectedLabelStyle: const TextStyle(
            fontSize: 12,
          ),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Stats',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.attach_money),
              label: 'Money',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.swap_horiz),
              label: 'Flips',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.flag),
              label: 'Goals',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.calculate),
              label: 'Calc',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }
}
