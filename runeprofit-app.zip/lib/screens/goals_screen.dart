import 'package:flutter/material.dart';
import 'package:runeprofit/models/goal.dart';
import 'package:runeprofit/services/goal_service.dart';
import 'package:runeprofit/widgets/goal_card.dart';
import 'package:runeprofit/widgets/add_goal_button.dart';
import 'package:runeprofit/widgets/theme_toggle_button.dart';

class GoalsScreen extends StatefulWidget {
  const GoalsScreen({Key? key}) : super(key: key);

  @override
  State<GoalsScreen> createState() => _GoalsScreenState();
}

class _GoalsScreenState extends State<GoalsScreen> {
  List<Goal> _goals = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadGoals();
  }

  Future<void> _loadGoals() async {
    setState(() {
      _isLoading = true;
    });
    
    final goals = await GoalService().getGoals();
    
    setState(() {
      _goals = goals;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Goals'),
        actions: [
          const ThemeToggleButton(),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadGoals,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _goals.length,
              itemBuilder: (context, index) {
                return GoalCard(goal: _goals[index]);
              },
            ),
      floatingActionButton: AddGoalButton(
        onGoalAdded: (goal) {
          setState(() {
            _goals.add(goal);
          });
        },
      ),
    );
  }
}
