import 'package:flutter/material.dart';
import 'package:runeprofit/models/flip.dart';
import 'package:runeprofit/services/flip_service.dart';
import 'package:runeprofit/widgets/flip_card.dart';
import 'package:runeprofit/widgets/theme_toggle_button.dart';

class FlipsScreen extends StatefulWidget {
  const FlipsScreen({Key? key}) : super(key: key);

  @override
  State<FlipsScreen> createState() => _FlipsScreenState();
}

class _FlipsScreenState extends State<FlipsScreen> {
  List<Flip> _flips = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFlips();
  }

  Future<void> _loadFlips() async {
    setState(() {
      _isLoading = true;
    });
    
    final flips = await FlipService().getFlips();
    
    setState(() {
      _flips = flips;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flipping Opportunities'),
        actions: [
          const ThemeToggleButton(),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadFlips,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _flips.length,
              itemBuilder: (context, index) {
                return FlipCard(flip: _flips[index]);
              },
            ),
    );
  }
}
