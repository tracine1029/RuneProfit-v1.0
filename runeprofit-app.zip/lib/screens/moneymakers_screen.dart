import 'package:flutter/material.dart';
import 'package:runeprofit/models/moneymaker.dart';
import 'package:runeprofit/services/moneymaker_service.dart';
import 'package:runeprofit/widgets/moneymaker_card.dart';
import 'package:runeprofit/widgets/theme_toggle_button.dart';

class MoneymakersScreen extends StatefulWidget {
  const MoneymakersScreen({Key? key}) : super(key: key);

  @override
  State<MoneymakersScreen> createState() => _MoneymakersScreenState();
}

class _MoneymakersScreenState extends State<MoneymakersScreen> {
  List<Moneymaker> _moneymakers = [];
  bool _isLoading = true;
  bool _ironmanMode = false;

  @override
  void initState() {
    super.initState();
    _loadMoneymakers();
  }

  Future<void> _loadMoneymakers() async {
    setState(() {
      _isLoading = true;
    });
    
    final moneymakers = await MoneymakerService().getMoneymakers(
      ironmanOnly: _ironmanMode,
    );
    
    setState(() {
      _moneymakers = moneymakers;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Money Makers'),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Switch(
                value: _ironmanMode,
                onChanged: (value) {
                  setState(() {
                    _ironmanMode = value;
                  });
                  _loadMoneymakers();
                },
              ),
              const SizedBox(width: 8),
              Text(
                'Ironman',
                style: TextStyle(
                  color: Theme.of(context).appBarTheme.foregroundColor,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(width: 16),
            ],
          ),
          const ThemeToggleButton(),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadMoneymakers,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _moneymakers.length,
              itemBuilder: (context, index) {
                return MoneymakerCard(moneymaker: _moneymakers[index]);
              },
            ),
    );
  }
}
