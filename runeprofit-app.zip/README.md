# RuneProfit - OSRS Helper App

A comprehensive Old School RuneScape (OSRS) companion application for money-making strategies, item flipping, goal tracking, and more.

## 🎮 Features

### 📊 Real-Time Data Integration
- **Live Price Data**: Real-time item prices from RuneScape Wiki API
- **Hiscores Integration**: Automatic stat lookup from OSRS hiscores
- **Market Analysis**: Advanced flipping opportunities with profit calculations
- **Dynamic Profit Updates**: Money-making methods updated with current market prices

### 💰 Money Making
- **Comprehensive Database**: 50+ money-making methods with detailed guides
- **Skill-Based Filtering**: Methods filtered by your current stats
- **Ironman Support**: Toggle for ironman-friendly methods only
- **Profit Calculator**: Built-in calculator for flip and investment analysis
- **Difficulty Ratings**: Methods categorized by difficulty and requirements

### 📈 Item Flipping
- **Live Opportunities**: Real-time profitable flipping suggestions
- **Volume Analysis**: High-volume items for consistent profits
- **ROI Calculations**: Return on investment and profit margin analysis
- **Market Trends**: Historical data and price movement tracking

### 🎯 Goal Tracking
- **Custom Goals**: Set and track personal OSRS objectives
- **Progress Monitoring**: Visual progress bars and completion tracking
- **Goal Categories**: Items, skills, quests, achievements, and custom goals
- **Milestone Celebrations**: Achievement notifications and progress updates

### 📱 User Experience
- **Dark Mode Support**: Full dark/light theme with OSRS-inspired design
- **Offline Capability**: Cached data for offline usage
- **Secure Storage**: Encrypted local storage for sensitive data
- **Cross-Platform**: Works on Android, iOS, and web

## 🚀 Installation

### Android
1. Download the latest APK from [Releases](https://github.com/yourusername/runeprofit/releases)
2. Enable "Install from Unknown Sources" in your device settings
3. Install the APK and launch RuneProfit

### iOS
1. Download from the App Store (coming soon)
2. Or build from source using Xcode

### Web
Visit [runeprofit.app](https://runeprofit.app) to use the web version

## 📖 Usage Guide

### Getting Started
1. **Import Your Stats**: Use hiscores lookup, RuneLite import, or manual entry
2. **Explore Money Makers**: Browse methods suitable for your stats
3. **Check Flipping Opportunities**: View current profitable items
4. **Set Goals**: Create and track your OSRS objectives
5. **Use Calculators**: Plan your investments and profits

### Features Overview

#### Stats Management
- **Hiscores Lookup**: Enter your username to automatically import stats
- **RuneLite Import**: Import your stats from RuneLite's export feature
- **Manual Entry**: Manually input your skill levels
- **Progress Tracking**: Monitor your skill progression over time

#### Money Making Methods
- **Filtering**: Filter by combat/skilling, ironman-friendly, difficulty
- **Requirements**: Clear skill and item requirements for each method
- **Step-by-Step Guides**: Detailed instructions for each method
- **Profit Updates**: Real-time profit calculations based on current prices

#### Flipping Tools
- **Live Data**: Updated every 5 minutes from RuneScape Wiki
- **Profit Analysis**: Detailed breakdown of potential profits
- **Volume Indicators**: High-volume items for consistent flipping
- **Market Insights**: Profit margins and ROI calculations

#### Goal System
- **Flexible Goals**: Set item, skill, quest, or custom objectives
- **Progress Tracking**: Visual progress bars and completion percentages
- **Categories**: Organize goals by type and priority
- **Achievements**: Celebrate completed goals and milestones

## 🛠️ Technical Details

### Built With
- **Flutter**: Cross-platform mobile development framework
- **Provider**: State management solution
- **HTTP**: Real-time API integration
- **Secure Storage**: Encrypted local data storage

### APIs Used
- **RuneScape Wiki API**: Real-time price data and item information
- **OSRS Hiscores**: Player statistics lookup
- **Item Database**: Comprehensive item information and images

### Data Sources
- **Prices**: RuneScape Wiki Real-time Prices API
- **Items**: OSRS Item Database
- **Player Stats**: Official OSRS Hiscores
- **Market Data**: Volume and historical price data

## 🔒 Privacy & Security

- **Local Storage**: All personal data stored locally on your device
- **No Tracking**: No analytics or user behavior tracking
- **Secure**: Encrypted storage for sensitive information
- **Open Source**: Full transparency with open-source code

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup
1. Clone the repository
2. Install Flutter dependencies: `flutter pub get`
3. Run the app: `flutter run`

### Reporting Issues
- Use GitHub Issues for bug reports and feature requests
- Provide detailed information and steps to reproduce
- Include device information and app version

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Jagex**: For creating Old School RuneScape
- **RuneScape Wiki**: For providing the excellent API
- **RuneLite**: For inspiration and community tools
- **OSRS Community**: For feedback and suggestions

## 📞 Support

- **GitHub Issues**: [Report bugs or request features](https://github.com/yourusername/runeprofit/issues)
- **Discord**: Join our community server (link coming soon)
- **Email**: support@runeprofit.app

---

**Disclaimer**: This app is not affiliated with or endorsed by Jagex Ltd. Old School RuneScape is a trademark of Jagex Ltd.
