package com.runeprofit.services;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.runeprofit.models.ItemPrice;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class PriceService
{
	private static final String WIKI_API_URL = "https://prices.runescape.wiki/api/v1/osrs/latest";
	private static final OkHttpClient client = new OkHttpClient.Builder()
		.connectTimeout(10, TimeUnit.SECONDS)
		.readTimeout(30, TimeUnit.SECONDS)
		.build();
	private static final Gson gson = new Gson();

	public static void updatePrices(Map<Integer, ItemPrice> itemPrices) throws IOException
	{
		Request request = new Request.Builder()
			.url(WIKI_API_URL)
			.addHeader("User-Agent", "RuneProfit RuneLite Plugin - Contact: your-email@example.com")
			.build();

		try (Response response = client.newCall(request).execute())
		{
			if (!response.isSuccessful())
			{
				throw new IOException("Failed to fetch prices: " + response.code());
			}

			String responseBody = response.body().string();
			JsonObject jsonResponse = gson.fromJson(responseBody, JsonObject.class);
			JsonObject data = jsonResponse.getAsJsonObject("data");

			long timestamp = System.currentTimeMillis();

			for (String itemIdStr : data.keySet())
			{
				try
				{
					int itemId = Integer.parseInt(itemIdStr);
					JsonObject itemData = data.getAsJsonObject(itemIdStr);

					Integer buyPrice = null;
					Integer sellPrice = null;

					if (itemData.has("low") && !itemData.get("low").isJsonNull())
					{
						buyPrice = itemData.get("low").getAsInt();
					}

					if (itemData.has("high") && !itemData.get("high").isJsonNull())
					{
						sellPrice = itemData.get("high").getAsInt();
					}

					if (buyPrice != null && sellPrice != null)
					{
						// Volume data would come from a separate API call
						int volume = 1000; // Default volume
						ItemPrice price = new ItemPrice(buyPrice, sellPrice, volume, timestamp);
						itemPrices.put(itemId, price);
					}
				}
				catch (NumberFormatException e)
				{
					// Skip invalid item IDs
				}
			}
		}
	}
}
