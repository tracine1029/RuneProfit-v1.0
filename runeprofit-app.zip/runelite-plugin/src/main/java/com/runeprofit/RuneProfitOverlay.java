package com.runeprofit;

import net.runelite.api.Client;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;
import net.runelite.client.ui.overlay.components.LineComponent;
import net.runelite.client.ui.overlay.components.PanelComponent;
import net.runelite.client.ui.overlay.components.TitleComponent;

import javax.inject.Inject;
import java.awt.*;
import java.text.NumberFormat;
import java.util.List;

public class RuneProfitOverlay extends Overlay
{
	private final Client client;
	private final RuneProfitPlugin plugin;
	private final RuneProfitConfig config;
	private final PanelComponent panelComponent = new PanelComponent();
	private final NumberFormat formatter = NumberFormat.getInstance();

	@Inject
	private RuneProfitOverlay(Client client, RuneProfitPlugin plugin, RuneProfitConfig config)
	{
		this.client = client;
		this.plugin = plugin;
		this.config = config;
		setPosition(OverlayPosition.TOP_LEFT);
		setLayer(OverlayLayer.ABOVE_WIDGETS);
	}

	@Override
	public Dimension render(Graphics2D graphics)
	{
		if (!config.showOverlay())
		{
			return null;
		}

		panelComponent.getChildren().clear();

		// Title
		panelComponent.getChildren().add(TitleComponent.builder()
			.text("RuneProfit")
			.color(Color.ORANGE)
			.build());

		// Player stats summary
		PlayerStats stats = plugin.getPlayerStats();
		if (stats != null)
		{
			panelComponent.getChildren().add(LineComponent.builder()
				.left("Total Level:")
				.right(String.valueOf(stats.getTotalLevel()))
				.build());

			panelComponent.getChildren().add(LineComponent.builder()
				.left("Combat Level:")
				.right(String.valueOf(stats.getCombatLevel()))
				.build());
		}

		// Top flip opportunities
		if (config.showRecommendations())
		{
			List<FlipOpportunity> flips = plugin.getFlipOpportunities();
			if (!flips.isEmpty())
			{
				panelComponent.getChildren().add(LineComponent.builder()
					.left("")
					.right("")
					.build());

				panelComponent.getChildren().add(TitleComponent.builder()
					.text("Top Flips")
					.color(Color.GREEN)
					.build());

				int count = Math.min(5, flips.size());
				for (int i = 0; i < count; i++)
				{
					FlipOpportunity flip = flips.get(i);
					panelComponent.getChildren().add(LineComponent.builder()
						.left(flip.getItemName())
						.right("+" + formatter.format(flip.getProfit()) + " gp")
						.rightColor(Color.GREEN)
						.build());
				}
			}
		}

		return panelComponent.render(graphics);
	}
}
