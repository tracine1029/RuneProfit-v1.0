package com.runeprofit;

import com.google.inject.Provides;
import javax.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.events.*;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.game.ItemManager;
import net.runelite.client.util.Text;
import java.util.*;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
@PluginDescriptor(
	name = "RuneProfit",
	description = "Advanced money-making and profit tracking for OSRS",
	tags = {"money", "profit", "flipping", "ge", "grand exchange"}
)
public class RuneProfitPlugin extends Plugin
{
	@Inject
	private Client client;

	@Inject
	private RuneProfitConfig config;

	@Inject
	private OverlayManager overlayManager;

	@Inject
	private RuneProfitOverlay overlay;

	@Inject
	private RuneProfitPanel panel;

	@Inject
	private ClientThread clientThread;

	@Inject
	private ItemManager itemManager;

	@Inject
	private ScheduledExecutorService executor;

	private final Map<Integer, ItemPrice> itemPrices = new HashMap<>();
	private final List<FlipOpportunity> flipOpportunities = new ArrayList<>();
	private final Map<String, MoneyMaker> moneyMakers = new HashMap<>();
	private PlayerStats playerStats;
	private long lastPriceUpdate = 0;
	private static final long PRICE_UPDATE_INTERVAL = 300000; // 5 minutes

	@Override
	protected void startUp() throws Exception
	{
		overlayManager.add(overlay);
		loadMoneyMakers();
		updatePlayerStats();
		
		// Schedule price updates
		executor.scheduleAtFixedRate(this::updatePrices, 0, 5, TimeUnit.MINUTES);
		
		log.info("RuneProfit started!");
	}

	@Override
	protected void shutDown() throws Exception
	{
		overlayManager.remove(overlay);
		log.info("RuneProfit stopped!");
	}

	@Subscribe
	public void onGameStateChanged(GameStateChanged gameStateChanged)
	{
		if (gameStateChanged.getGameState() == GameState.LOGGED_IN)
		{
			updatePlayerStats();
		}
	}

	@Subscribe
	public void onStatChanged(StatChanged statChanged)
	{
		updatePlayerStats();
		updateRecommendedMethods();
	}

	@Subscribe
	public void onGrandExchangeOfferChanged(GrandExchangeOfferChanged event)
	{
		GrandExchangeOffer offer = event.getOffer();
		if (offer.getState() == GrandExchangeOfferState.BOUGHT || 
			offer.getState() == GrandExchangeOfferState.SOLD)
		{
			trackTransaction(offer);
		}
	}

	@Subscribe
	public void onChatMessage(ChatMessage event)
	{
		if (event.getType() == ChatMessageType.GAMEMESSAGE)
		{
			String message = Text.removeTags(event.getMessage());
			
			// Track loot drops for profit calculation
			if (message.contains("You receive") || message.contains("drops"))
			{
				parseLootMessage(message);
			}
		}
	}

	private void updatePlayerStats()
	{
		if (client.getLocalPlayer() == null)
			return;

		Map<String, Integer> skills = new HashMap<>();
		Map<String, Integer> experience = new HashMap<>();
		
		for (Skill skill : Skill.values())
		{
			if (skill == Skill.OVERALL)
				continue;
				
			int level = client.getRealSkillLevel(skill);
			int xp = client.getSkillExperience(skill);
			
			skills.put(skill.getName().toLowerCase(), level);
			experience.put(skill.getName().toLowerCase(), xp);
		}
		
		playerStats = new PlayerStats(skills, experience);
		updateRecommendedMethods();
	}

	private void updateRecommendedMethods()
	{
		if (playerStats == null)
			return;

		List<MoneyMaker> recommended = new ArrayList<>();
		
		for (MoneyMaker method : moneyMakers.values())
		{
			if (meetsRequirements(method))
			{
				recommended.add(method);
			}
		}
		
		// Sort by profit per hour
		recommended.sort((a, b) -> Integer.compare(b.getGpPerHour(), a.getGpPerHour()));
		
		panel.updateRecommendedMethods(recommended);
	}

	private boolean meetsRequirements(MoneyMaker method)
	{
		for (Map.Entry<String, Integer> req : method.getSkillRequirements().entrySet())
		{
			String skillName = req.getKey();
			int requiredLevel = req.getValue();
			int playerLevel = playerStats.getSkills().getOrDefault(skillName, 1);
			
			if (playerLevel < requiredLevel)
			{
				return false;
			}
		}
		
		// Check ironman mode
		if (config.ironmanMode() && !method.isIronmanFriendly())
		{
			return false;
		}
		
		return true;
	}

	private void updatePrices()
	{
		if (System.currentTimeMillis() - lastPriceUpdate < PRICE_UPDATE_INTERVAL)
			return;

		clientThread.invokeLater(() -> {
			try
			{
				// Fetch prices from RuneScape Wiki API
				PriceService.updatePrices(itemPrices);
				updateFlipOpportunities();
				lastPriceUpdate = System.currentTimeMillis();
				
				log.info("Updated {} item prices", itemPrices.size());
			}
			catch (Exception e)
			{
				log.error("Failed to update prices", e);
			}
		});
	}

	private void updateFlipOpportunities()
	{
		flipOpportunities.clear();
		
		for (Map.Entry<Integer, ItemPrice> entry : itemPrices.entrySet())
		{
			int itemId = entry.getKey();
			ItemPrice price = entry.getValue();
			
			if (price.getBuyPrice() > 0 && price.getSellPrice() > 0)
			{
				int profit = price.getSellPrice() - price.getBuyPrice();
				double margin = (double) profit / price.getBuyPrice() * 100;
				
				// Filter profitable items
				if (profit > config.minProfit() && margin > config.minMargin())
				{
					String itemName = itemManager.getItemComposition(itemId).getName();
					FlipOpportunity flip = new FlipOpportunity(
						itemId, itemName, price.getBuyPrice(), price.getSellPrice(),
						profit, margin, price.getVolume()
					);
					flipOpportunities.add(flip);
				}
			}
		}
		
		// Sort by profit
		flipOpportunities.sort((a, b) -> Integer.compare(b.getProfit(), a.getProfit()));
		
		panel.updateFlipOpportunities(flipOpportunities);
	}

	private void trackTransaction(GrandExchangeOffer offer)
	{
		// Track GE transactions for profit analysis
		String itemName = itemManager.getItemComposition(offer.getItemId()).getName();
		int totalPrice = offer.getPrice() * offer.getTotalQuantity();
		
		if (offer.getState() == GrandExchangeOfferState.BOUGHT)
		{
			log.info("Bought {} x {} for {} gp each", 
				offer.getTotalQuantity(), itemName, offer.getPrice());
		}
		else if (offer.getState() == GrandExchangeOfferState.SOLD)
		{
			log.info("Sold {} x {} for {} gp each", 
				offer.getTotalQuantity(), itemName, offer.getPrice());
		}
		
		panel.addTransaction(new Transaction(offer, itemName));
	}

	private void parseLootMessage(String message)
	{
		// Parse loot messages to track PvM profits
		// This would be expanded to handle various loot formats
		if (message.contains("coins"))
		{
			// Extract coin amount and track
		}
	}

	private void loadMoneyMakers()
	{
		// Load money-making methods
		moneyMakers.put("vorkath", new MoneyMaker(
			"vorkath", "Killing Vorkath", 3500000,
			Map.of("ranged", 80, "defence", 75, "hitpoints", 75),
			false, "Very Hard", "Combat"
		));
		
		moneyMakers.put("toa", new MoneyMaker(
			"toa", "Tombs of Amascut", 4500000,
			Map.of("attack", 90, "strength", 90, "defence", 90, "ranged", 90, "magic", 94),
			true, "Extreme", "Combat"
		));
		
		moneyMakers.put("blood_runes", new MoneyMaker(
			"blood_runes", "Crafting Blood Runes", 1400000,
			Map.of("runecraft", 77, "mining", 38),
			true, "Medium", "Skilling"
		));
		
		// Add more methods...
	}

	public List<FlipOpportunity> getFlipOpportunities()
	{
		return new ArrayList<>(flipOpportunities);
	}

	public PlayerStats getPlayerStats()
	{
		return playerStats;
	}

	public Map<String, MoneyMaker> getMoneyMakers()
	{
		return moneyMakers;
	}

	@Provides
	RuneProfitConfig provideConfig(ConfigManager configManager)
	{
		return configManager.getConfig(RuneProfitConfig.class);
	}
}
