package com.runeprofit;

import net.runelite.client.ui.ColorScheme;
import net.runelite.client.ui.PluginPanel;
import net.runelite.client.ui.components.PluginErrorPanel;
import net.runelite.client.util.ImageUtil;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.List;

public class RuneProfitPanel extends PluginPanel
{
	private final JPanel contentPanel = new JPanel();
	private final JTabbedPane tabbedPane = new JTabbedPane();
	private final JPanel methodsPanel = new JPanel();
	private final JPanel flipsPanel = new JPanel();
	private final JPanel statsPanel = new JPanel();
	private final JPanel transactionsPanel = new JPanel();
	private final NumberFormat formatter = NumberFormat.getInstance();

	public RuneProfitPanel()
	{
		super(false);
		setBackground(ColorScheme.DARK_GRAY_COLOR);
		setLayout(new BorderLayout());

		// Header
		JPanel headerPanel = new JPanel();
		headerPanel.setBackground(ColorScheme.DARKER_GRAY_COLOR);
		headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
		headerPanel.setLayout(new BorderLayout());

		JLabel titleLabel = new JLabel("RuneProfit");
		titleLabel.setForeground(Color.WHITE);
		titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
		headerPanel.add(titleLabel, BorderLayout.WEST);

		add(headerPanel, BorderLayout.NORTH);

		// Tabbed content
		setupTabs();
		add(tabbedPane, BorderLayout.CENTER);

		// Initialize panels
		initializeMethodsPanel();
		initializeFlipsPanel();
		initializeStatsPanel();
		initializeTransactionsPanel();
	}

	private void setupTabs()
	{
		tabbedPane.setBackground(ColorScheme.DARKER_GRAY_COLOR);
		tabbedPane.addTab("Methods", methodsPanel);
		tabbedPane.addTab("Flips", flipsPanel);
		tabbedPane.addTab("Stats", statsPanel);
		tabbedPane.addTab("Transactions", transactionsPanel);
	}

	private void initializeMethodsPanel()
	{
		methodsPanel.setLayout(new BorderLayout());
		methodsPanel.setBackground(ColorScheme.DARK_GRAY_COLOR);

		JLabel label = new JLabel("Recommended money-making methods will appear here");
		label.setForeground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		methodsPanel.add(label, BorderLayout.CENTER);
	}

	private void initializeFlipsPanel()
	{
		flipsPanel.setLayout(new BorderLayout());
		flipsPanel.setBackground(ColorScheme.DARK_GRAY_COLOR);

		JLabel label = new JLabel("Profitable flipping opportunities will appear here");
		label.setForeground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		flipsPanel.add(label, BorderLayout.CENTER);
	}

	private void initializeStatsPanel()
	{
		statsPanel.setLayout(new BorderLayout());
		statsPanel.setBackground(ColorScheme.DARK_GRAY_COLOR);

		JLabel label = new JLabel("Your stats and progress will appear here");
		label.setForeground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		statsPanel.add(label, BorderLayout.CENTER);
	}

	private void initializeTransactionsPanel()
	{
		transactionsPanel.setLayout(new BorderLayout());
		transactionsPanel.setBackground(ColorScheme.DARK_GRAY_COLOR);

		JLabel label = new JLabel("Your GE transactions will appear here");
		label.setForeground(Color.WHITE);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		transactionsPanel.add(label, BorderLayout.CENTER);
	}

	public void updateRecommendedMethods(List<MoneyMaker> methods)
	{
		SwingUtilities.invokeLater(() -> {
			methodsPanel.removeAll();
			methodsPanel.setLayout(new BoxLayout(methodsPanel, BoxLayout.Y_AXIS));

			if (methods.isEmpty())
			{
				JLabel noMethodsLabel = new JLabel("No suitable methods found for your stats");
				noMethodsLabel.setForeground(Color.WHITE);
				noMethodsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
				methodsPanel.add(noMethodsLabel);
			}
			else
			{
				for (MoneyMaker method : methods)
				{
					JPanel methodPanel = createMethodPanel(method);
					methodsPanel.add(methodPanel);
					methodsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
				}
			}

			methodsPanel.revalidate();
			methodsPanel.repaint();
		});
	}

	public void updateFlipOpportunities(List<FlipOpportunity> flips)
	{
		SwingUtilities.invokeLater(() -> {
			flipsPanel.removeAll();
			flipsPanel.setLayout(new BoxLayout(flipsPanel, BoxLayout.Y_AXIS));

			if (flips.isEmpty())
			{
				JLabel noFlipsLabel = new JLabel("No profitable flips found");
				noFlipsLabel.setForeground(Color.WHITE);
				noFlipsLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
				flipsPanel.add(noFlipsLabel);
			}
			else
			{
				for (FlipOpportunity flip : flips)
				{
					JPanel flipPanel = createFlipPanel(flip);
					flipsPanel.add(flipPanel);
					flipsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
				}
			}

			flipsPanel.revalidate();
			flipsPanel.repaint();
		});
	}

	public void addTransaction(Transaction transaction)
	{
		SwingUtilities.invokeLater(() -> {
			// Add transaction to the transactions panel
			// Implementation would depend on Transaction class structure
		});
	}

	private JPanel createMethodPanel(MoneyMaker method)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(ColorScheme.DARKER_GRAY_COLOR);
		panel.setBorder(BorderFactory.createLineBorder(ColorScheme.MEDIUM_GRAY_COLOR));

		// Method name and profit
		JPanel headerPanel = new JPanel(new BorderLayout());
		headerPanel.setBackground(ColorScheme.DARKER_GRAY_COLOR);

		JLabel nameLabel = new JLabel(method.getName());
		nameLabel.setForeground(Color.WHITE);
		nameLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

		JLabel profitLabel = new JLabel(formatter.format(method.getGpPerHour()) + " gp/hr");
		profitLabel.setForeground(Color.GREEN);
		profitLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

		headerPanel.add(nameLabel, BorderLayout.WEST);
		headerPanel.add(profitLabel, BorderLayout.EAST);

		// Difficulty and category
		JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		infoPanel.setBackground(ColorScheme.DARKER_GRAY_COLOR);

		JLabel difficultyLabel = new JLabel(method.getDifficulty());
		difficultyLabel.setForeground(getDifficultyColor(method.getDifficulty()));
		difficultyLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

		JLabel categoryLabel = new JLabel(" | " + method.getCategory());
		categoryLabel.setForeground(Color.LIGHT_GRAY);
		categoryLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

		infoPanel.add(difficultyLabel);
		infoPanel.add(categoryLabel);

		panel.add(headerPanel, BorderLayout.NORTH);
		panel.add(infoPanel, BorderLayout.SOUTH);

		return panel;
	}

	private JPanel createFlipPanel(FlipOpportunity flip)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(ColorScheme.DARKER_GRAY_COLOR);
		panel.setBorder(BorderFactory.createLineBorder(ColorScheme.MEDIUM_GRAY_COLOR));

		// Item name and profit
		JPanel headerPanel = new JPanel(new BorderLayout());
		headerPanel.setBackground(ColorScheme.DARKER_GRAY_COLOR);

		JLabel nameLabel = new JLabel(flip.getItemName());
		nameLabel.setForeground(Color.WHITE);
		nameLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

		JLabel profitLabel = new JLabel("+" + formatter.format(flip.getProfit()) + " gp");
		profitLabel.setForeground(Color.GREEN);
		profitLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));

		headerPanel.add(nameLabel, BorderLayout.WEST);
		headerPanel.add(profitLabel, BorderLayout.EAST);

		// Buy/sell prices and margin
		JPanel pricePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pricePanel.setBackground(ColorScheme.DARKER_GRAY_COLOR);

		JLabel buyLabel = new JLabel("Buy: " + formatter.format(flip.getBuyPrice()));
		buyLabel.setForeground(Color.LIGHT_GRAY);
		buyLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

		JLabel sellLabel = new JLabel(" | Sell: " + formatter.format(flip.getSellPrice()));
		sellLabel.setForeground(Color.LIGHT_GRAY);
		sellLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

		JLabel marginLabel = new JLabel(" | " + String.format("%.1f%%", flip.getMargin()));
		marginLabel.setForeground(Color.YELLOW);
		marginLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));

		pricePanel.add(buyLabel);
		pricePanel.add(sellLabel);
		pricePanel.add(marginLabel);

		panel.add(headerPanel, BorderLayout.NORTH);
		panel.add(pricePanel, BorderLayout.SOUTH);

		return panel;
	}

	private Color getDifficultyColor(String difficulty)
	{
		switch (difficulty.toLowerCase())
		{
			case "easy":
				return Color.GREEN;
			case "medium":
				return Color.YELLOW;
			case "hard":
				return Color.ORANGE;
			case "very hard":
				return Color.RED;
			case "extreme":
				return Color.MAGENTA;
			default:
				return Color.WHITE;
		}
	}
}
