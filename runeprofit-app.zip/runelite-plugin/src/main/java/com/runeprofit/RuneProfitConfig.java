package com.runeprofit;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;
import net.runelite.client.config.ConfigSection;

@ConfigGroup("runeprofit")
public interface RuneProfitConfig extends Config
{
	@ConfigSection(
		name = "General",
		description = "General settings",
		position = 0
	)
	String generalSection = "general";

	@ConfigSection(
		name = "Flipping",
		description = "Item flipping settings",
		position = 1
	)
	String flippingSection = "flipping";

	@ConfigSection(
		name = "Overlay",
		description = "Overlay settings",
		position = 2
	)
	String overlaySection = "overlay";

	@ConfigItem(
		keyName = "ironmanMode",
		name = "Ironman Mode",
		description = "Filter methods for ironman accounts",
		section = generalSection
	)
	default boolean ironmanMode()
	{
		return false;
	}

	@ConfigItem(
		keyName = "showRecommendations",
		name = "Show Recommendations",
		description = "Show recommended money-making methods",
		section = generalSection
	)
	default boolean showRecommendations()
	{
		return true;
	}

	@ConfigItem(
		keyName = "minProfit",
		name = "Minimum Profit",
		description = "Minimum profit per item for flipping suggestions",
		section = flippingSection
	)
	default int minProfit()
	{
		return 100;
	}

	@ConfigItem(
		keyName = "minMargin",
		name = "Minimum Margin %",
		description = "Minimum profit margin percentage",
		section = flippingSection
	)
	default double minMargin()
	{
		return 2.0;
	}

	@ConfigItem(
		keyName = "maxFlips",
		name = "Max Flip Suggestions",
		description = "Maximum number of flip suggestions to show",
		section = flippingSection
	)
	default int maxFlips()
	{
		return 20;
	}

	@ConfigItem(
		keyName = "showOverlay",
		name = "Show Overlay",
		description = "Show the RuneProfit overlay",
		section = overlaySection
	)
	default boolean showOverlay()
	{
		return true;
	}

	@ConfigItem(
		keyName = "overlayPosition",
		name = "Overlay Position",
		description = "Position of the overlay on screen",
		section = overlaySection
	)
	default OverlayPosition overlayPosition()
	{
		return OverlayPosition.TOP_LEFT;
	}

	enum OverlayPosition
	{
		TOP_LEFT,
		TOP_RIGHT,
		BOTTOM_LEFT,
		BOTTOM_RIGHT
	}
}
