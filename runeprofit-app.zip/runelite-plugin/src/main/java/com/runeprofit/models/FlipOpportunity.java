package com.runeprofit.models;

public class FlipOpportunity
{
	private final int itemId;
	private final String itemName;
	private final int buyPrice;
	private final int sellPrice;
	private final int profit;
	private final double margin;
	private final int volume;

	public FlipOpportunity(int itemId, String itemName, int buyPrice, int sellPrice,
						   int profit, double margin, int volume)
	{
		this.itemId = itemId;
		this.itemName = itemName;
		this.buyPrice = buyPrice;
		this.sellPrice = sellPrice;
		this.profit = profit;
		this.margin = margin;
		this.volume = volume;
	}

	public int getItemId() { return itemId; }
	public String getItemName() { return itemName; }
	public int getBuyPrice() { return buyPrice; }
	public int getSellPrice() { return sellPrice; }
	public int getProfit() { return profit; }
	public double getMargin() { return margin; }
	public int getVolume() { return volume; }
}
