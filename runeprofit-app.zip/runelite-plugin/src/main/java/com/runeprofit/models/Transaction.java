package com.runeprofit.models;

import net.runelite.api.GrandExchangeOffer;

public class Transaction
{
	private final GrandExchangeOffer offer;
	private final String itemName;
	private final long timestamp;

	public Transaction(GrandExchangeOffer offer, String itemName)
	{
		this.offer = offer;
		this.itemName = itemName;
		this.timestamp = System.currentTimeMillis();
	}

	public GrandExchangeOffer getOffer() { return offer; }
	public String getItemName() { return itemName; }
	public long getTimestamp() { return timestamp; }
}
