package com.runeprofit.models;

import java.util.Map;

public class MoneyMaker
{
	private final String id;
	private final String name;
	private final int gpPerHour;
	private final Map<String, Integer> skillRequirements;
	private final boolean ironmanFriendly;
	private final String difficulty;
	private final String category;

	public MoneyMaker(String id, String name, int gpPerHour, Map<String, Integer> skillRequirements,
					  boolean ironmanFriendly, String difficulty, String category)
	{
		this.id = id;
		this.name = name;
		this.gpPerHour = gpPerHour;
		this.skillRequirements = skillRequirements;
		this.ironmanFriendly = ironmanFriendly;
		this.difficulty = difficulty;
		this.category = category;
	}

	public String getId() { return id; }
	public String getName() { return name; }
	public int getGpPerHour() { return gpPerHour; }
	public Map<String, Integer> getSkillRequirements() { return skillRequirements; }
	public boolean isIronmanFriendly() { return ironmanFriendly; }
	public String getDifficulty() { return difficulty; }
	public String getCategory() { return category; }
}
