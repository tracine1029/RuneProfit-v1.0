package com.runeprofit.models;

import java.util.Map;

public class PlayerStats
{
	private final Map<String, Integer> skills;
	private final Map<String, Integer> experience;

	public PlayerStats(Map<String, Integer> skills, Map<String, Integer> experience)
	{
		this.skills = skills;
		this.experience = experience;
	}

	public Map<String, Integer> getSkills()
	{
		return skills;
	}

	public Map<String, Integer> getExperience()
	{
		return experience;
	}

	public int getTotalLevel()
	{
		return skills.values().stream().mapToInt(Integer::intValue).sum();
	}

	public int getCombatLevel()
	{
		int attack = skills.getOrDefault("attack", 1);
		int strength = skills.getOrDefault("strength", 1);
		int defence = skills.getOrDefault("defence", 1);
		int hitpoints = skills.getOrDefault("hitpoints", 10);
		int ranged = skills.getOrDefault("ranged", 1);
		int magic = skills.getOrDefault("magic", 1);
		int prayer = skills.getOrDefault("prayer", 1);

		double base = 0.25 * (defence + hitpoints + Math.floor(prayer / 2.0));
		double melee = 0.325 * (attack + strength);
		double ranger = 0.325 * Math.floor(ranged * 1.5);
		double mage = 0.325 * Math.floor(magic * 1.5);

		return (int) Math.floor(base + Math.max(melee, Math.max(ranger, mage)));
	}
}
