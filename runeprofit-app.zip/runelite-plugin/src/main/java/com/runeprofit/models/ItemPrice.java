package com.runeprofit.models;

public class ItemPrice
{
	private final int buyPrice;
	private final int sellPrice;
	private final int volume;
	private final long timestamp;

	public ItemPrice(int buyPrice, int sellPrice, int volume, long timestamp)
	{
		this.buyPrice = buyPrice;
		this.sellPrice = sellPrice;
		this.volume = volume;
		this.timestamp = timestamp;
	}

	public int getBuyPrice() { return buyPrice; }
	public int getSellPrice() { return sellPrice; }
	public int getVolume() { return volume; }
	public long getTimestamp() { return timestamp; }
}
