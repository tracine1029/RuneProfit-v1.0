# RuneProfit RuneLite Plugin

A comprehensive RuneLite plugin for advanced money-making, profit tracking, and market analysis in Old School RuneScape.

## Features

### 🎯 Smart Money-Making Recommendations
- **Skill-Based Filtering**: Automatically shows methods you can actually do
- **Real-Time Profit Updates**: GP/hour calculations based on current market prices
- **Difficulty Ratings**: Easy to Extreme classifications with color coding
- **Ironman Support**: Toggle for ironman-friendly methods only

### 📈 Advanced Flipping Tools
- **Live Market Data**: Real-time prices from RuneScape Wiki API
- **Profit Analysis**: Detailed margin calculations and ROI metrics
- **Volume Tracking**: High-volume items for consistent profits
- **Customizable Filters**: Set minimum profit and margin thresholds

### 📊 Comprehensive Tracking
- **GE Transaction History**: Automatic tracking of all Grand Exchange trades
- **Profit/Loss Analysis**: Track your trading performance over time
- **Loot Tracking**: Monitor PvM drops and calculate hourly profits
- **Statistics Dashboard**: Detailed stats and progress tracking

### 🎮 Seamless Integration
- **Overlay Display**: In-game overlay with key information
- **Side Panel**: Detailed plugin panel with tabbed interface
- **Real-Time Updates**: Automatic price updates every 5 minutes
- **Configurable Settings**: Customize all aspects of the plugin

## Installation

### Method 1: Plugin Hub (Recommended)
1. Open RuneLite
2. Click the Plugin Hub button (puzzle piece icon)
3. Search for "RuneProfit"
4. Click Install

### Method 2: Manual Installation
1. Download the latest `.jar` file from [Releases](https://github.com/yourusername/runeprofit-plugin/releases)
2. Place it in your RuneLite plugins folder:
   - Windows: `%USERPROFILE%\.runelite\plugins`
   - macOS: `~/.runelite/plugins`
   - Linux: `~/.runelite/plugins`
3. Restart RuneLite

### Method 3: Build from Source
\`\`\`bash
git clone https://github.com/yourusername/runeprofit-plugin.git
cd runeprofit-plugin
mvn clean package
\`\`\`

## Configuration

### General Settings
- **Ironman Mode**: Filter methods for ironman accounts
- **Show Recommendations**: Toggle method recommendations
- **Update Interval**: How often to refresh price data

### Flipping Settings
- **Minimum Profit**: Minimum GP profit per item (default: 100)
- **Minimum Margin**: Minimum profit percentage (default: 2%)
- **Max Suggestions**: Number of flip opportunities to show (default: 20)

### Overlay Settings
- **Show Overlay**: Toggle the in-game overlay
- **Overlay Position**: Choose overlay position on screen
- **Overlay Content**: Customize what information to display

## Usage Guide

### Getting Started
1. Enable the plugin in RuneLite settings
2. Open the RuneProfit side panel
3. Your stats will be automatically detected
4. Browse recommended methods and flip opportunities

### Money-Making Methods
- **Browse by Category**: Combat, Skilling, or All methods
- **Filter by Stats**: Only shows methods you can actually do
- **Difficulty Levels**: Color-coded from Easy (green) to Extreme (magenta)
- **Profit Estimates**: Updated with current market prices

### Item Flipping
- **Live Opportunities**: Updated every 5 minutes with fresh data
- **Profit Calculations**: Includes GE tax and realistic margins
- **Volume Analysis**: Focus on high-volume items for consistent profits
- **Price Alerts**: Get notified when profitable opportunities arise

### Transaction Tracking
- **Automatic Detection**: All GE trades are automatically tracked
- **Profit Analysis**: See your actual profits and losses
- **Performance Metrics**: Track your success rate and ROI
- **Export Data**: Export your trading history for analysis

## API Integration

### RuneScape Wiki API
- **Real-Time Prices**: Latest buy/sell prices for all items
- **Volume Data**: Trading volume for market analysis
- **Historical Data**: Price trends and market patterns

### Data Sources
- **Item Database**: Comprehensive item information and images
- **Price History**: Historical price data for trend analysis
- **Market Metrics**: Volume, volatility, and liquidity data

## Development

### Building the Plugin
\`\`\`bash
# Clone the repository
git clone https://github.com/yourusername/runeprofit-plugin.git
cd runeprofit-plugin

# Build with Maven
mvn clean compile package

# The built JAR will be in target/runeprofit-1.0.0.jar
\`\`\`

### Project Structure
\`\`\`
src/main/java/com/runeprofit/
├── RuneProfitPlugin.java          # Main plugin class
├── RuneProfitConfig.java          # Configuration interface
├── RuneProfitOverlay.java         # In-game overlay
├── RuneProfitPanel.java           # Side panel UI
├── models/                        # Data models
│   ├── PlayerStats.java
│   ├── MoneyMaker.java
│   ├── FlipOpportunity.java
│   ├── ItemPrice.java
│   └── Transaction.java
└── services/                      # Business logic
    └── PriceService.java          # API integration
\`\`\`

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## Troubleshooting

### Common Issues

**Plugin not loading**
- Ensure you have the latest RuneLite version
- Check that the plugin file is in the correct directory
- Restart RuneLite completely

**Prices not updating**
- Check your internet connection
- Verify the RuneScape Wiki API is accessible
- Try manually refreshing in the plugin settings

**Overlay not showing**
- Enable the overlay in plugin configuration
- Check overlay position settings
- Ensure RuneLite overlays are enabled globally

### Support
- **GitHub Issues**: [Report bugs or request features](https://github.com/yourusername/runeprofit-plugin/issues)
- **Discord**: Join our community server for help and discussion
- **Reddit**: Post in /r/RuneLite for community support

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Disclaimer

This plugin is not affiliated with or endorsed by Jagex Ltd. Old School RuneScape is a trademark of Jagex Ltd. Use at your own risk.

## Changelog

### v1.0.0
- Initial release
- Money-making method recommendations
- Real-time flipping opportunities
- GE transaction tracking
- Configurable overlay and settings
\`\`\`

Now let me create the downloadable files:
