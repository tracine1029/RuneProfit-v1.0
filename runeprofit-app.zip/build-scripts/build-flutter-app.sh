#!/bin/bash

# RuneProfit Flutter App Build Script
echo "Building RuneProfit Flutter App..."

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "Flutter is not installed. Please install Flutter first."
    exit 1
fi

# Clean previous builds
echo "Cleaning previous builds..."
flutter clean

# Get dependencies
echo "Getting dependencies..."
flutter pub get

# Build for different platforms
echo "Building for Android..."
flutter build apk --release

echo "Building for Android App Bundle..."
flutter build appbundle --release

echo "Building for Web..."
flutter build web --release

# Create iOS build (if on macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "Building for iOS..."
    flutter build ios --release --no-codesign
fi

# Create release directory
mkdir -p releases

# Copy built files
cp build/app/outputs/flutter-apk/app-release.apk releases/runeprofit-android.apk
cp build/app/outputs/bundle/release/app-release.aab releases/runeprofit-android.aab

# Copy web build
cp -r build/web releases/runeprofit-web

echo "Build complete! Files available in releases/ directory"
echo ""
echo "Android APK: releases/runeprofit-android.apk"
echo "Android Bundle: releases/runeprofit-android.aab"
echo "Web Build: releases/runeprofit-web/"

if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "iOS Build: build/ios/Release-iphoneos/Runner.app"
fi
