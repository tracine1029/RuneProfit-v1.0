#!/bin/bash

# RuneProfit RuneLite Plugin Build Script
echo "Building RuneProfit RuneLite Plugin..."

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Maven is not installed. Please install Maven first."
    exit 1
fi

# Navigate to plugin directory
cd runelite-plugin

# Clean and build
echo "Cleaning previous builds..."
mvn clean

echo "Compiling and packaging..."
mvn compile package

# Create release directory
mkdir -p ../releases

# Copy built JAR
cp target/runeprofit-1.0.0.jar ../releases/runeprofit-runelite-plugin.jar

echo "Plugin build complete!"
echo "Plugin JAR: releases/runeprofit-runelite-plugin.jar"
echo ""
echo "Installation Instructions:"
echo "1. Copy runeprofit-runelite-plugin.jar to your RuneLite plugins folder"
echo "2. Restart RuneLite"
echo "3. Enable the RuneProfit plugin in settings"
